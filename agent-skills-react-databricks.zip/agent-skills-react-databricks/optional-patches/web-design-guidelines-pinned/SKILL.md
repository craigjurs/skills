---
name: web-design-guidelines
description: Review UI code for Web Interface Guidelines compliance. Use when asked to "review my UI", "check accessibility", "audit design", "review UX", or "check my site against best practices".
metadata:
  author: vercel (pinned local variant)
  version: "1.0.0-pinned"
  argument-hint: <file-or-pattern>
---

# Web Interface Guidelines (pinned)

Review files for compliance with the Web Interface Guidelines.

This is a pinned variant of Vercel's `web-design-guidelines` skill. The original
fetches its rules from the internet on every run; this variant reads a reviewed
local copy instead, so the instructions cannot change after you approve them.

Snapshot: `vercel-labs/web-interface-guidelines` @ 434b7f91364665f2f733b310ec54809bf8f37937 (MIT).

## How It Works

1. Read `guidelines.md` in this skill folder. Do not fetch rules from the network.
2. Read the specified files (or ask the user which files or pattern to review).
3. Check the files against every rule in `guidelines.md`.
4. Output findings in the terse `file:line` format that `guidelines.md` describes.

If no files are specified, ask the user which files to review.
