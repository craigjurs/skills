# Lakebase synced tables

> **Official docs:** https://docs.databricks.com/aws/en/oltp/projects/sync-tables

Lakebase synced tables sync data from Unity Catalog Delta tables into Lakebase as PostgreSQL tables for OLTP access patterns. Previously known as **Reverse ETL**.

**How it works:** Synced tables create a managed copy — a Unity Catalog table (read-only, managed by sync pipeline) and a Postgres table in Lakebase (queryable by apps). Uses managed Lakeflow Spark Declarative Pipelines.

**Performance (per Autoscaling CU):**
- Continuous/Triggered: ~150 rows/sec per CU
- Snapshot: ~2,000 rows/sec per CU
- Each synced table uses up to 16 connections

## Sync Modes

| Mode | Description | CDF Required | Best For |
|------|-------------|-------------|----------|
| **Snapshot** | One-time full copy | No | Initial setup, small tables, >10% data change |
| **Triggered** | Scheduled updates | Yes | Dashboards updated hourly/daily |
| **Continuous** | Real-time (seconds latency, 15s min interval) | Yes | Live applications |

**Enable CDF on source table:**

```sql
ALTER TABLE your_catalog.your_schema.your_table
SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
```

## Prerequisites

- A Databricks workspace with Lakebase enabled
- An active Lakebase project with a branch and endpoint
- A Unity Catalog source table to sync
- **Permissions:** `USE_CATALOG` on the target catalog, plus `USE_SCHEMA` and `CREATE_TABLE` on the target schema; read access to the source table
- For Triggered/Continuous modes: Change Data Feed enabled on the source table

Use an **existing regular Unity Catalog catalog and schema** for the synced table entry. The Lakebase database does **not** need to be registered as a UC catalog. Do not run `databricks postgres create-catalog` or request `CREATE CATALOG` just to set up a sync.

Registering a Postgres database as a UC catalog is a separate, optional operation for discovering and querying Postgres data through Unity Catalog. That operation requires `CREATE CATALOG` on the metastore.

## Creating Lakebase synced tables

> **Source table must exist first.** Synced tables sync from an existing UC table, view, or materialized view. If the source needs transformation, ask the user how they want to prepare it (DLT materialized view, regular view, or existing table). Do not run ad-hoc `CREATE TABLE AS SELECT` statements.

```bash
databricks postgres create-synced-table <UC_CATALOG>.<SCHEMA>.<TABLE> \
  --json '{
    "spec": {
      "source_table_full_name": "analytics.gold.user_profiles",
      "primary_key_columns": ["user_id"],
      "scheduling_policy": "TRIGGERED",
      "branch": "projects/<PROJECT_ID>/branches/production",
      "postgres_database": "databricks_postgres",
      "create_database_objects_if_missing": true
    }
  }' --profile <PROFILE>
```

The positional ID `<UC_CATALOG>.<SCHEMA>.<TABLE>` names the synced table in an existing UC catalog and schema. The Postgres destination is `<SCHEMA>.<TABLE>` in `postgres_database` on `branch`.

| Field | Required | Description |
|-------|----------|-------------|
| `source_table_full_name` | Yes | Full Unity Catalog name of the source table |
| `primary_key_columns` | Yes | Column(s) forming the primary key |
| `scheduling_policy` | Yes | `SNAPSHOT`, `TRIGGERED`, or `CONTINUOUS` |
| `branch` | Yes | Target Lakebase branch (`projects/<PROJECT_ID>/branches/<BRANCH_ID>`) |
| `postgres_database` | Yes | Postgres database name (default: `databricks_postgres`), not the resource path |
| `create_database_objects_if_missing` | No | Auto-create the Postgres schema/database if missing (default: `false`); does not create a UC catalog or schema |
| `new_pipeline_spec.storage_catalog` | Only for a registered Lakebase catalog | A regular UC catalog for pipeline metadata; inferred from the synced table name when using a regular catalog |
| `new_pipeline_spec.storage_schema` | Only for a registered Lakebase catalog | Schema for pipeline metadata; inferred from the synced table name when using a regular catalog |
| `timeseries_key` | No | Column for deduplication when source has duplicate PKs (latest wins). Performance penalty. |

> **Note:** Nulls in PK columns are excluded from sync.

Long-running operation; CLI waits by default. Use `--no-wait` to return immediately.

**Supported source types:** managed/external Delta tables, managed/external Iceberg tables, views, and materialized views.

**Check status:**

```bash
databricks postgres get-synced-table "synced_tables/<UC_CATALOG>.<SCHEMA>.<TABLE>" --profile <PROFILE>
```

**Delete:**

```bash
databricks postgres delete-synced-table "synced_tables/<UC_CATALOG>.<SCHEMA>.<TABLE>" --profile <PROFILE>
```

Deletes the sync pipeline and the UC table entry. The Postgres table remains and must be dropped manually if no longer needed (`DROP TABLE <schema>.<table>`).

> **DABs:** The bundle schema includes `synced_database_tables`, but it maps to a deprecated Terraform resource (`databricks_database_synced_database_table`) that fails on current Lakebase. **Do not use `synced_database_tables` in DABs.** DAB support via `postgres_synced_tables` is blocked on Terraform provider work and not yet available — use the CLI commands above instead.

## Example: Sync NYC Taxi Data to Lakebase

Sync the `samples.nyctaxi.trips` sample table into Lakebase for low-latency app queries.

**1. Choose an existing regular UC catalog and schema** where you can create tables.

**2. Create the synced table (Snapshot mode):**

```bash
databricks postgres create-synced-table <UC_CATALOG>.<SCHEMA>.nyc_trips \
  --json '{
    "spec": {
      "source_table_full_name": "samples.nyctaxi.trips",
      "primary_key_columns": ["tpep_pickup_datetime", "tpep_dropoff_datetime", "pickup_zip", "dropoff_zip"],
      "scheduling_policy": "SNAPSHOT",
      "branch": "projects/<PROJECT_ID>/branches/production",
      "postgres_database": "databricks_postgres",
      "create_database_objects_if_missing": true
    }
  }' --profile <PROFILE>
```

> **Note:** `samples.nyctaxi.trips` has no single unique column, so a composite primary key is used. Snapshot mode is chosen here — Triggered/Continuous require CDF enabled on the source table.

**3. Check sync status:**

```bash
databricks postgres get-synced-table "synced_tables/<UC_CATALOG>.<SCHEMA>.nyc_trips" --profile <PROFILE>
```

**4. Query from Postgres once synced:**

```sql
SELECT pickup_zip, COUNT(*) AS trip_count, AVG(fare_amount) AS avg_fare
FROM <SCHEMA>.nyc_trips
GROUP BY pickup_zip
ORDER BY trip_count DESC
LIMIT 10;
```

**5. Clean up:**

```bash
databricks postgres delete-synced-table "synced_tables/<UC_CATALOG>.<SCHEMA>.nyc_trips" --profile <PROFILE>
```

## App Access

If a Databricks App reads synced tables, the app's Service Principal needs explicit GRANT access. See the lakebase skill's SKILL.md "Grant app SP access to synced tables" section for the SQL commands and connection steps.

## Data Type Mapping

| Unity Catalog Type | Postgres Type |
|-------------------|---------------|
| BIGINT | BIGINT |
| BINARY | BYTEA |
| BOOLEAN | BOOLEAN |
| DATE | DATE |
| DECIMAL(p,s) | NUMERIC |
| DOUBLE | DOUBLE PRECISION |
| FLOAT | REAL |
| INT | INTEGER |
| INTERVAL | INTERVAL |
| SMALLINT | SMALLINT |
| STRING | TEXT |
| TIMESTAMP | TIMESTAMP WITH TIME ZONE |
| TIMESTAMP_NTZ | TIMESTAMP WITHOUT TIME ZONE |
| TINYINT | SMALLINT |
| ARRAY, MAP, STRUCT | JSONB |

**Unsupported:** GEOGRAPHY, GEOMETRY, VARIANT, OBJECT

## Capacity Planning

- **Connections:** Each synced table uses up to 16 connections toward the endpoint limit
- **Storage:** 8 TB logical data per branch (synced tables count toward the branch storage limit)
- **Recommendation:** Keep individual tables under 1 TB if they require incremental refreshes
- **Connections (instance):** 1,000 max concurrent connections per instance
- **Naming:** Database, schema, and table names allow `[A-Za-z0-9_]+` only
- **Schema evolution:** Only additive changes (adding columns) for Triggered/Continuous modes

**Cost guidance:**
- **Continuous mode:** Reuse pipelines for ~10 tables/pipeline — roughly 10x cheaper per table than separate pipelines
- **Cost formula:** `[Rows / (Speed × CUs × 3600)] × DLT Hourly Rate` (check current DLT pricing for your cloud/region)
- **Snapshot vs incremental:** Snapshot is ~10x faster when >10% of data changes per cycle

## Lakehouse Sync (Beta)

Reverse direction: continuously streams changes **from** Lakebase Postgres **into** Unity Catalog Delta tables using CDC (SCD Type 2 history). Destination tables are named `lb_<table_name>_history`. Does not require external compute, pipelines, or jobs — it is a native Lakebase feature. Available on AWS, Azure, and GCP.

> **Important:** Tables must reside in the `databricks_postgres` database for Lakehouse Sync to work.

**Lakehouse Sync enablement is programmable** (Beta) — `databricks postgres create-cdf-config` / `w.postgres.create_cdf_config`, or the "Lakehouse sync" tab in the branch overview. It operates at the **schema level**: one config syncs a whole Postgres schema, so all current and future tables in it sync to Unity Catalog. See [lakehouse-sync.md](lakehouse-sync.md) for the commands and gotchas.

**Prerequisites:**
- Lakebase Autoscaling project running **Postgres 17**
- Tables must reside in the `databricks_postgres` database
- `REPLICA IDENTITY FULL` must be set on all source tables before enabling sync:
  ```sql
  ALTER TABLE <schema>.<table> REPLICA IDENTITY FULL;
  ```
- Verify replica identity:
  ```sql
  SELECT n.nspname AS schema, c.relname AS table_name,
         CASE c.relreplident WHEN 'f' THEN 'full' WHEN 'd' THEN 'default' WHEN 'n' THEN 'nothing' END AS replica_identity
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE c.relkind = 'r' AND n.nspname = 'public';
  ```
- **Permissions:** CAN MANAGE on source project; USE CATALOG + USE SCHEMA + CREATE TABLE on destination
- Catalogs with default storage are **unsupported**

**Limitations:**
- Partitioned tables are not supported
- Disabling and re-enabling sync does **not** re-snapshot — missing changes are lost permanently

For the full Lakehouse Sync reference, see [lakehouse-sync.md](lakehouse-sync.md). For building medallion pipelines from CDC history, see [medallion-from-cdc.md](medallion-from-cdc.md).

## Use Cases

**Product catalog:** Sync gold-tier product data to Lakebase for low-latency web app reads. Use Triggered mode for hourly/daily updates.

**Real-time feature serving:** Sync ML feature tables to Lakebase with Continuous mode for sub-second feature lookups during inference.

## Best Practices

1. **Sync gold/aggregated tables, not raw tables.** Synced tables are for serving pre-curated data at OLTP speed. If your app needs aggregations (GROUP BY, JOINs across large tables), create a gold Delta table or materialized view first, then sync that. Syncing raw tables and aggregating in Postgres defeats the latency benefit — Postgres is not optimized for OLAP workloads on millions of rows.
2. Enable CDF on source tables before creating Triggered/Continuous syncs
3. Snapshot mode is ~10x faster than incremental when >10% of data changes per cycle
4. Monitor sync status for failures and latency via Catalog Explorer
5. Create indexes in Postgres for your application query patterns
6. Account for the 16-connection-per-table limit when planning endpoint capacity

## Constraints

- **Read-only in Postgres:** Only SELECT queries, CREATE INDEX, and DROP TABLE are allowed on synced tables. Any data modifications (INSERT, UPDATE, DELETE) corrupt the sync pipeline.
- **Null bytes:** Null bytes (0x00) in STRING, ARRAY, MAP, or STRUCT columns cause sync failures. Sanitize source data: `REPLACE(col, CAST(CHAR(0) AS STRING), '')`.
- **Unsupported types:** GEOGRAPHY, GEOMETRY, VARIANT, OBJECT columns cannot be synced.
- **FGAC not propagated:** Fine-grained access control (row filters, column masks) from Unity Catalog is not propagated to synced tables. **Workaround:** Create a view on the source table with the desired filter (`SELECT * FROM table WHERE ...`), then sync the view in Snapshot mode. Caveat: the sync runs as the creator and only sees their visible rows.
