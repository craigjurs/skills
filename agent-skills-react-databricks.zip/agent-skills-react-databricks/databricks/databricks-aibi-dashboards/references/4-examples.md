# Complete Dashboard Example

A working dashboard JSON that exercises the new feature set:

- **`dataset.columns[]` + `MEASURE()`** — reusable named measures across widgets.
- **`forecast-line`** with `AI_FORECAST` SQL and a **vertical-line annotation** for a known event.
- **`pivot`** with conditional cell coloring.
- **`symbol-map`** (lat/lon) with a continuous color ramp.
- **`range-slider`** filter on a numeric column.
- **Counter sparkline** via the `period` encoding.

**Adapt this to the user's actual data and story** — the structure and feature mix is what to copy, not the column names.

## Key Patterns (read first)

### Page types
- `PAGE_TYPE_CANVAS` — content page with widgets.
- `PAGE_TYPE_GLOBAL_FILTERS` — dedicated filter page, applies to all canvas pages whose datasets contain the filter field.

### Widget versions used in this example

| Widget | Version |
|---|---|
| `counter`, `table`, `filter-*`, `range-slider`, `symbol-map` | **2** |
| `bar`, `line`, `area`, `pie`, `pivot`, `histogram`, `heatmap` | **3** |
| `combo`, `choropleth-map`, `forecast-line`, `sankey`, `funnel`, `box`, `waterfall` | **1** |

See [SKILL.md](../SKILL.md#widget-index-version--where-documented) for the full version table.

### Layout (12-col grid)

```
y=0:   Header (w=12, h=3)  ← story prose tying the dashboard together
y=3:   KPI (w=3) | KPI w/ sparkline (w=3) | KPI (w=3) | KPI (w=3)  ← fills 12
y=6:   Forecast w/ release annotation (w=8, h=6)  | Histogram (w=4, h=8)
y=12:  Symbol map (w=8, h=5)                      |
y=14:                                             | Pie by channel (w=4, h=4)
y=17:  Detail table (w=8, h=7)                    |
y=18:                                             | Heatmap (w=4, h=6)
```

The right-hand column uses **staggered heights** — the histogram extends past the forecast, the pie sits in the middle, the heatmap aligns to the bottom of the detail table. The widgets on the left and right don't share row boundaries; the engine tolerates this as long as the canvas reads naturally. Pair tall widgets on one side with several shorter ones on the other to vary the rhythm rather than forcing strict row alignment.

This example's header carries a short narrative tying the widgets together, and the forecast widget uses a `vertical-line` annotation to mark a notable date. That's one way to structure a story — useful if there's a real inflection point in the data — but it's not required: a dashboard can also just present the metrics neutrally, or anchor the story on a different widget. Treat it as illustrative.

---

## Full Dashboard: Support Operations

```json
{
  "datasets": [
    {
      "name": "ds_support",
      "displayName": "Support cases",
      "queryLines": [
        "SELECT case_id, opened_at, closed_at, priority, channel, region_name,\n",
        "       customer_id, reopened_flag, satisfaction_score,\n",
        "       customer_latitude, customer_longitude,\n",
        "       (unix_timestamp(closed_at) - unix_timestamp(opened_at)) / 3600.0 AS time_to_resolution_hours\n",
        "FROM support_cases"
      ],
      "columns": [
        {
          "displayName": "Total Cases",
          "description": "Count of support cases",
          "expression": "COUNT(`case_id`)"
        },
        {
          "displayName": "Avg Resolution Hours",
          "description": "Mean resolution time across closed cases",
          "expression": "AVG(`time_to_resolution_hours`)"
        },
        {
          "displayName": "Reopen Rate %",
          "description": "Percent of cases reopened after closure",
          "expression": "SUM(CASE WHEN `reopened_flag`=true THEN 1 ELSE 0 END) * 1.0 / COUNT(`case_id`)"
        },
        {
          "displayName": "Avg Satisfaction",
          "description": "Average customer satisfaction (1-10)",
          "expression": "AVG(`satisfaction_score`)"
        },
        {
          "displayName": "Priority Level",
          "description": "Sortable priority label",
          "expression": "CASE WHEN `priority`='Critical' THEN '1-Critical' WHEN `priority`='High' THEN '2-High' WHEN `priority`='Medium' THEN '3-Medium' ELSE '4-Low' END"
        }
      ]
    },
    {
      "name": "ds_forecast",
      "displayName": "Cases forecast",
      "queryLines": [
        "WITH actuals AS (\n",
        "  SELECT DATE_TRUNC('WEEK', opened_at) AS opened_at, COUNT(*) AS count\n",
        "  FROM support_cases\n",
        "  WHERE DATE_TRUNC('WEEK', opened_at) < DATE_TRUNC('WEEK', current_date())\n",
        "  GROUP BY 1\n",
        "),\n",
        "dates AS (SELECT MAX(opened_at) AS max_d, MIN(opened_at) AS min_d FROM actuals),\n",
        "forecast AS (\n",
        "  SELECT opened_at, count_forecast, count_upper, count_lower, CAST(NULL AS BIGINT) AS count\n",
        "  FROM AI_FORECAST(TABLE(actuals),\n",
        "    horizon  => (SELECT max_d + MAKE_DT_INTERVAL(CAST(FLOOR(DATEDIFF(max_d, min_d) * 0.5) AS INT), 0, 0, 0) FROM dates),\n",
        "    time_col => 'opened_at', value_col => 'count')\n",
        "),\n",
        "bridge AS (\n",
        "  SELECT a.opened_at, a.count AS count_forecast, a.count AS count_upper, a.count AS count_lower, a.count\n",
        "  FROM actuals a JOIN dates d ON a.opened_at = d.max_d\n",
        ")\n",
        "SELECT opened_at, CAST(NULL AS BIGINT) AS count_forecast, CAST(NULL AS BIGINT) AS count_upper, CAST(NULL AS BIGINT) AS count_lower, count FROM actuals\n",
        "UNION ALL SELECT opened_at, count_forecast, count_upper, count_lower, count FROM bridge\n",
        "UNION ALL SELECT opened_at, count_forecast, count_upper, count_lower, count FROM forecast"
      ]
    }
  ],
  "pages": [
    {
      "name": "overview",
      "displayName": "Overview",
      "layout": [
        {
          "widget": {
            "name": "header",
            "multilineTextboxSpec": {
              "lines": [
                "# Support Operations \u2014 Post-Release Surge (4.1)\n",
                "\n",
                "**The story this week:** a clear volume spike in mid-February \u2014 the date the new Product 4.1 release went out (marked on the forecast chart). The release introduced a regression that drove a wave of Critical/High cases over the following 6 weeks: case volume jumps, average resolution time creeps up, reopen rate climbs, and customer satisfaction dips on the affected metros \u2014 visible on the satisfaction map as warmer (lower) scores. The forecast extends the trend forward so the team can size the cleanup ahead. Use the filters page to slice by region or resolution-time bucket to localize the impact."
              ]
            }
          },
          "position": {
            "x": 0,
            "y": 0,
            "width": 12,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "kpi-total-cases",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "measure(Total Cases)",
                      "expression": "MEASURE(`Total Cases`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "counter",
              "encodings": {
                "value": {
                  "fieldName": "measure(Total Cases)",
                  "displayName": "Total Cases"
                }
              },
              "frame": {
                "title": "Total Cases",
                "showTitle": true
              }
            }
          },
          "position": {
            "x": 0,
            "y": 3,
            "width": 3,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "kpi-volume-trend",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "weekly(opened_at)",
                      "expression": "DATE_TRUNC(\"WEEK\", `opened_at`)"
                    },
                    {
                      "name": "measure(Total Cases)",
                      "expression": "MEASURE(`Total Cases`)"
                    }
                  ],
                  "disaggregated": false,
                  "orders": [
                    {
                      "direction": "DESC",
                      "expression": "DATE_TRUNC(\"WEEK\", `opened_at`)"
                    }
                  ]
                }
              }
            ],
            "spec": {
              "version": 2,
              "frame": {
                "title": "Daily Case Volume ",
                "showTitle": true
              },
              "widgetType": "counter",
              "encodings": {
                "value": {
                  "fieldName": "measure(Total Cases)",
                  "displayName": "This Week"
                },
                "period": {
                  "fieldName": "weekly(opened_at)"
                }
              }
            }
          },
          "position": {
            "x": 3,
            "y": 3,
            "width": 3,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "kpi-resolution",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "measure(Avg Resolution Hours)",
                      "expression": "MEASURE(`Avg Resolution Hours`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "frame": {
                "title": "Avg Resolution Time",
                "showTitle": true
              },
              "widgetType": "counter",
              "encodings": {
                "value": {
                  "fieldName": "measure(Avg Resolution Hours)",
                  "format": {"type": "number-plain", "decimalPlaces": {"type": "max", "places": 1}},
                  "formatTemplate": "{{ @formatted }} hrs",
                  "displayName": "Avg Hours"
                }
              }
            }
          },
          "position": {
            "x": 6,
            "y": 3,
            "width": 3,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "kpi-reopen",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "measure(Reopen Rate %)",
                      "expression": "MEASURE(`Reopen Rate %`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "frame": {
                "title": "Reopen Rate (%)",
                "showTitle": true
              },
              "widgetType": "counter",
              "encodings": {
                "value": {
                  "fieldName": "measure(Reopen Rate %)",
                  "format": {
                    "type": "number-percent",
                    "decimalPlaces": {
                      "type": "max",
                      "places": 2
                    }
                  },
                  "displayName": "Reopen Rate"
                }
              }
            }
          },
          "position": {
            "x": 9,
            "y": 3,
            "width": 3,
            "height": 3
          }
        },
        {
          "widget": {
            "name": "case-forecast",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_forecast",
                  "fields": [
                    {
                      "name": "opened_at",
                      "expression": "`opened_at`"
                    },
                    {
                      "name": "count",
                      "expression": "`count`"
                    },
                    {
                      "name": "count_forecast",
                      "expression": "`count_forecast`"
                    },
                    {
                      "name": "count_upper",
                      "expression": "`count_upper`"
                    },
                    {
                      "name": "count_lower",
                      "expression": "`count_lower`"
                    }
                  ],
                  "disaggregated": true
                }
              }
            ],
            "spec": {
              "version": 1,
              "widgetType": "forecast-line",
              "encodings": {
                "x": {
                  "fieldName": "opened_at",
                  "scale": {
                    "type": "temporal"
                  }
                },
                "y": {
                  "scale": {
                    "type": "quantitative",
                    "domainMin": 0
                  },
                  "original": {
                    "fieldName": "count",
                    "displayName": "Cases"
                  },
                  "prediction": {
                    "fieldName": "count_forecast",
                    "displayName": "Forecast"
                  },
                  "predictionUpper": {
                    "fieldName": "count_upper"
                  },
                  "predictionLower": {
                    "fieldName": "count_lower"
                  }
                }
              },
              "annotations": [
                {
                  "type": "vertical-line",
                  "encodings": {
                    "x": {
                      "dataValue": "2026-02-16T09:00:00.000",
                      "dataType": "DATETIME"
                    },
                    "label": {
                      "value": "Product release 4.1"
                    },
                    "color": {
                      "value": {
                        "hex": "#FF7E5C"
                      }
                    }
                  }
                }
              ],
              "frame": {
                "showTitle": true,
                "title": "Case Volume \u2014 actuals + forecast"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 6,
            "width": 8,
            "height": 6
          }
        },
        {
          "widget": {
            "name": "priority-by-channel",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "count(case_id)",
                      "expression": "COUNT(`case_id`)"
                    },
                    {
                      "name": "Priority Level",
                      "expression": "`Priority Level`"
                    },
                    {
                      "name": "channel",
                      "expression": "`channel`"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 3,
              "frame": {
                "showTitle": true,
                "title": "Cases by channel \u00d7 priority"
              },
              "widgetType": "heatmap",
              "encodings": {
                "x": {
                  "fieldName": "Priority Level",
                  "scale": {
                    "type": "categorical"
                  }
                },
                "y": {
                  "fieldName": "channel",
                  "scale": {
                    "type": "categorical"
                  }
                },
                "color": {
                  "fieldName": "count(case_id)",
                  "scale": {
                    "type": "quantitative",
                    "colorRamp": {
                      "mode": "custom-sequential",
                      "colors": {
                        "start": "#FFA600",
                        "end": "#995495"
                      }
                    }
                  }
                },
                "label": {
                  "show": true
                }
              }
            }
          },
          "position": {
            "x": 8,
            "y": 18,
            "width": 4,
            "height": 6
          }
        },
        {
          "widget": {
            "name": "customer-map",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "measure(Avg Satisfaction)",
                      "expression": "MEASURE(`Avg Satisfaction`)"
                    },
                    {
                      "name": "customer_latitude",
                      "expression": "`customer_latitude`"
                    },
                    {
                      "name": "customer_longitude",
                      "expression": "`customer_longitude`"
                    },
                    {
                      "name": "count(*)",
                      "expression": "COUNT(`*`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "frame": {
                "showTitle": true,
                "title": "Customer Satisfaction Map"
              },
              "mark": {
                "opacity": 0.7
              },
              "widgetType": "symbol-map",
              "encodings": {
                "coordinates": {
                  "latitude": {
                    "fieldName": "customer_latitude"
                  },
                  "longitude": {
                    "fieldName": "customer_longitude"
                  }
                },
                "color": {
                  "fieldName": "measure(Avg Satisfaction)",
                  "scale": {
                    "type": "quantitative",
                    "colorRamp": {
                      "mode": "custom-sequential",
                      "colors": {
                        "start": "#FFDC00",
                        "end": "#995495"
                      }
                    }
                  }
                },
                "size": {
                  "fieldName": "count(*)",
                  "scale": {
                    "type": "quantitative"
                  }
                }
              }
            }
          },
          "position": {
            "x": 0,
            "y": 12,
            "width": 8,
            "height": 5
          }
        },
        {
          "widget": {
            "name": "resolution-distribution",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "channel",
                      "expression": "`channel`"
                    },
                    {
                      "name": "bin(time_to_resolution_hours, binWidth=2)",
                      "expression": "BIN_FLOOR(`time_to_resolution_hours`, 2)"
                    },
                    {
                      "name": "count(*)",
                      "expression": "COUNT(`*`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 3,
              "frame": {
                "showTitle": true,
                "title": "Resolution time (hours)"
              },
              "widgetType": "histogram",
              "encodings": {
                "x": {
                  "fieldName": "bin(time_to_resolution_hours, binWidth=2)",
                  "scale": {
                    "type": "quantitative",
                    "domain": {
                      "max": 175
                    }
                  }
                },
                "y": {
                  "fieldName": "count(*)",
                  "scale": {
                    "type": "quantitative"
                  }
                },
                "color": {
                  "fieldName": "channel",
                  "scale": {
                    "type": "categorical",
                    "mappings": [
                      {
                        "value": "Email",
                        "color": "#FF7054"
                      }
                    ]
                  }
                }
              }
            }
          },
          "position": {
            "x": 8,
            "y": 6,
            "width": 4,
            "height": 8
          }
        },
        {
          "widget": {
            "name": "case-detail",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "case_id",
                      "expression": "`case_id`"
                    },
                    {
                      "name": "opened_at",
                      "expression": "`opened_at`"
                    },
                    {
                      "name": "channel",
                      "expression": "`channel`"
                    },
                    {
                      "name": "Priority Level",
                      "expression": "`Priority Level`"
                    },
                    {
                      "name": "time_to_resolution_hours",
                      "expression": "`time_to_resolution_hours`"
                    },
                    {
                      "name": "satisfaction_score",
                      "expression": "`satisfaction_score`"
                    }
                  ],
                  "disaggregated": true
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "table",
              "encodings": {
                "columns": [
                  {
                    "fieldName": "case_id",
                    "displayName": "Case"
                  },
                  {
                    "fieldName": "opened_at",
                    "displayName": "Opened"
                  },
                  {
                    "fieldName": "channel",
                    "displayName": "Channel"
                  },
                  {
                    "fieldName": "Priority Level",
                    "displayName": "Priority"
                  },
                  {
                    "fieldName": "time_to_resolution_hours",
                    "displayName": "Hours to resolve",
                    "format": {
                      "type": "number",
                      "decimalPlaces": {
                        "type": "exact",
                        "places": 1
                      }
                    },
                    "style": {
                      "type": "basic",
                      "rules": [
                        {
                          "condition": {
                            "operand": {
                              "type": "data-value",
                              "value": "24"
                            },
                            "operator": ">"
                          },
                          "backgroundColor": {
                            "hex": "#FF7E5C"
                          }
                        }
                      ]
                    }
                  },
                  {
                    "fieldName": "satisfaction_score",
                    "displayName": "CSAT"
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Case Detail"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 17,
            "width": 8,
            "height": 7
          }
        },
        {
          "widget": {
            "name": "b4dd0785",
            "queries": [
              {
                "name": "main_query",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "measure(Total Cases)",
                      "expression": "MEASURE(`Total Cases`)"
                    },
                    {
                      "name": "channel",
                      "expression": "`channel`"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 3,
              "frame": {
                "showTitle": true,
                "title": "Cases by channel",
                "showDescription": true,
                "description": "Distribution of support cases across intake channels."
              },
              "widgetType": "pie",
              "encodings": {
                "angle": {
                  "fieldName": "measure(Total Cases)",
                  "scale": {
                    "type": "quantitative"
                  },
                  "displayName": "Cases"
                },
                "color": {
                  "fieldName": "channel",
                  "displayName": "Channel",
                  "scale": {
                    "type": "categorical",
                    "mappings": [
                      {
                        "value": "Email",
                        "color": "#FF7054"
                      },
                      {
                        "value": "Chat",
                        "color": "#FFA600"
                      },
                      {
                        "value": "Phone",
                        "color": "#DE5582"
                      },
                      {
                        "value": "Web Form",
                        "color": "#995495"
                      }
                    ]
                  }
                },
                "label": {
                  "show": true
                }
              }
            }
          },
          "position": {
            "x": 8,
            "y": 14,
            "width": 4,
            "height": 4
          }
        }
      ],
      "pageType": "PAGE_TYPE_CANVAS",
      "layoutVersion": "GRID_V1"
    },
    {
      "name": "filters",
      "displayName": "Filters",
      "layout": [
        {
          "widget": {
            "name": "filter-date",
            "queries": [
              {
                "name": "ds_date",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "opened_at",
                      "expression": "`opened_at`"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-date-range-picker",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "opened_at",
                    "queryName": "ds_date"
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Date"
              }
            }
          },
          "position": {
            "x": 0,
            "y": 0,
            "width": 4,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter-region",
            "queries": [
              {
                "name": "ds_region",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "region_name",
                      "expression": "`region_name`"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "filter-multi-select",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "region_name",
                    "queryName": "ds_region",
                    "displayName": "Region"
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Region"
              }
            }
          },
          "position": {
            "x": 4,
            "y": 0,
            "width": 4,
            "height": 2
          }
        },
        {
          "widget": {
            "name": "filter-resolution-time",
            "queries": [
              {
                "name": "ds_resolution",
                "query": {
                  "datasetName": "ds_support",
                  "fields": [
                    {
                      "name": "min(time_to_resolution_hours)",
                      "expression": "MIN(`time_to_resolution_hours`)"
                    },
                    {
                      "name": "max(time_to_resolution_hours)",
                      "expression": "MAX(`time_to_resolution_hours`)"
                    }
                  ],
                  "disaggregated": false
                }
              }
            ],
            "spec": {
              "version": 2,
              "widgetType": "range-slider",
              "encodings": {
                "fields": [
                  {
                    "fieldName": "time_to_resolution_hours",
                    "queryName": "ds_resolution"
                  }
                ]
              },
              "frame": {
                "showTitle": true,
                "title": "Resolution time (hrs)"
              }
            }
          },
          "position": {
            "x": 8,
            "y": 0,
            "width": 4,
            "height": 2
          }
        }
      ],
      "pageType": "PAGE_TYPE_GLOBAL_FILTERS",
      "layoutVersion": "GRID_V1"
    }
  ],
  "uiSettings": {
    "theme": {
      "canvasBackgroundColor": {
        "light": "#FCFCFC",
        "dark": "#1F272D"
      },
      "widgetBackgroundColor": {
        "light": "#FFFFFF",
        "dark": "#11171C"
      },
      "widgetBorderColor": {
        "light": "#FFFFFF",
        "dark": "#11171C"
      },
      "fontColor": {
        "light": "#11171C",
        "dark": "#E8ECF0"
      },
      "selectionColor": {
        "light": "#2272B4",
        "dark": "#8ACAFF"
      },
      "visualizationColors": [
        "#FFA600",
        "#FF7054",
        "#DE5582",
        "#995495",
        "#4E5185",
        "#1D425C",
        "#99DDB4"
      ],
      "widgetHeaderAlignment": "LEFT"
    }
  }
}
```

This is the "warm sunset" family used in the live Customer Support dashboard — amber → coral → pink → purple → navy, plus a mint-green at position 6 (0-indexed) for "good/safe" semantic use. The categorical palette covers chart series; **the alert/critical color (`#FF7E5C`) is pinned as a literal `hex` in the conditional-cell rules and the annotation** (NOT a palette position), so semantic meaning holds even if the palette is reshuffled later.

## What each widget demonstrates

| Widget | Feature shown |
|---|---|
| 4 KPI counters | `MEASURE()` referencing dataset-level `columns[]` |
| `kpi-volume-trend` counter | `period` encoding (sparkline behind the value) |
| `case-forecast` | `forecast-line` with `AI_FORECAST` SQL + `vertical-line` annotation |
| `priority-by-channel` | `pivot` with conditional cell-color rules |
| `customer-map` | `symbol-map` with continuous `colorRamp` |
| `resolution-distribution` | `histogram` with `bin(col, binWidth=N)` |
| `case-detail` table | per-column `format` + conditional `style.rules` for high-hour cells |
| `filter-resolution-time` | `range-slider` filter on a numeric column |
| Global filters page | Filters bound to one source dataset cascade to every widget that uses it |

Adapt the table names, columns, story, and palette to your domain — the structure stays the same.
