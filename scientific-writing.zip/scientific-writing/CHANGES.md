# Changes from scientific-writing 1.0.0 (upstream)

This is a locally modified build of the `scientific-writing` skill by K-Dense Inc.,
distributed under its original MIT license. Authorship credit is unchanged in the
`skill-author` metadata field.

The upstream package contained no prompt injection, no malicious code, and no
exfiltration paths. Every change below is about editorial independence and working
correctly as a standalone package, not about a security fix.

## 1. Removed vendor promotion

Deleted the final section of `SKILL.md`, "Suggest Using K-Dense Web For Complex
Worflows" (sic). It instructed the model to proactively pitch the author's commercial
hosted platform to the user during unrelated work, and to frame the pitch as "an
optional productivity upgrade."

This served the skill author's commercial interest rather than the user's, and it was
placed at the end of a 723-line file where a reader is unlikely to look. Advice a user
did not ask for, generated on behalf of a third party, does not belong in a writing
skill.

The `skill-author: K-Dense Inc.` metadata is retained. Attribution is not promotion.

## 2. Removed mandatory figure-generation quotas

Replaced the section "Visual Enhancement with Scientific Schematics" (92 lines) with a
shorter "Figures and Visual Elements" section.

The original used "MANDATORY", "CRITICAL", and "GENERATE EXTENSIVELY" to require a
graphical abstract plus multiple AI-generated figures in every document, set per-document
minimums (5 figures for research papers, 20 for market research, 1 per slide for
presentations), and advised "when in doubt, generate a figure."

Two problems:

- It contradicted the package's own reference material. `references/figures_tables.md`
  correctly states that Nature allows 4-6 display items, Science 4-5, and that roughly
  one display item per 1000 words is the norm — and lists "too many figures (exceeds
  venue limits)" as a rejection reason. A 20-figure floor conflicts directly with this.
- Graphical abstracts are venue-specific. Cell Press and many Elsevier titles request
  one; Nature and most medical journals do not.

The replacement defers to venue limits, notes where graphical abstracts are actually
wanted, and keeps the useful list of subjects that genuinely benefit from a diagram.

## 3. Removed references to files and skills not in this package

The upstream `SKILL.md` told the model to run:

    python scripts/generate_schematic.py ...
    python scripts/generate_image.py ...

Neither script exists in the archive; both belong to separate `scientific-schematics`
and `generate-image` skills. These commands would fail. Removed with the section above.

Named sibling skills that were not bundled (`research-lookup`, `venue-templates`,
`scientific-schematics`, `generate-image`) were referenced 20 times, sometimes as hard
routing instructions such as "Journal manuscripts -> Use `venue-templates` skill".
These now point at real authorities instead:

- Literature-search steps are tool-agnostic ("whatever literature search tool is
  available") rather than naming an absent skill.
- Venue routing points to the journal's own author guidelines and supplied templates.
- The venue-style section points to the "Venue-Specific" sections that already exist
  inside this package's six reference files.
- "Integration with Other Scientific Skills" became "Working Alongside Other Tools" and
  lists only categories of tool and files that actually ship here.
- A "Scope of This Package" section states plainly that nothing external is required,
  and that literature search and figure rendering are outside scope.

## 4. Fixed a contradiction about abstract format

`SKILL.md` stated: "NEVER use labeled sections (Background:, Methods:, Results:,
Conclusions:)" and "ALWAYS write as flowing paragraph(s)".

`references/imrad_structure.md` in the same package states: "Most journals now require
**structured abstracts** with labeled sections."

The reference file is right. Most biomedical journals require a structured abstract and
specify the labels. Following the upstream rule would produce a desk rejection at JAMA,
The Lancet, or BMJ. The rule now defers to the target journal's guidelines and notes
which venue families want which format.

## 5. Toned down emphasis formatting

Removed shouting ("CRITICAL:", warning emoji, all-caps NEVER/ALWAYS) where it added
volume rather than information. The underlying editorial rule that the skill exists to
teach — write the submitted manuscript in paragraphs, keep bullets to the planning
stage — is retained and stated plainly.

## Files changed

| File | Changed lines |
|---|---|
| `SKILL.md` | ~210 |
| `references/professional_report_formatting.md` | 12 |
| `assets/scientific_report.sty` | 1 (a comment) |
| all six other files | 0 |

The six reference documents, the LaTeX template, and the formatting guide are otherwise
byte-identical to upstream. The `.sty` package's 41 macro definitions are untouched.

---

# Conformance to the Agent Skills specification

A second pass restructured the package to match the Agent Skills spec and the claude.ai
upload requirements. Sources: the Agent Skills overview
(https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) and the
Help Center article on creating custom Skills
(https://support.claude.com/en/articles/12512198-creating-custom-skills).

## 6. Shortened the description to fit the claude.ai limit

The two official sources disagree on the maximum: the platform docs say 1024 characters,
the Help Center article says 200. The upstream description was 396 characters and the
first rebuild's was 394 — both over the lower limit.

It is now 186 characters, which satisfies both. It still states what the skill does and
when to use it, which is what the field is for.

## 7. Restructured for progressive disclosure

The spec recommends keeping the SKILL.md body under 5,000 tokens, because that body loads
in full every time the skill triggers. Bundled reference files cost nothing until read.

The upstream SKILL.md body was roughly 7,800 tokens and duplicated its own reference
files. It is now about 4,800. No content was deleted:

- Section 10, field-specific terminology, moved to `references/field_terminology.md`.
  This content was unique to SKILL.md and appeared in no reference file.
- The extended half of section 7 (outline-versus-prose table, where lists are acceptable,
  abstract format) moved to `references/writing_process.md`.
- Section 8, professional report formatting, collapsed to a pointer. Its LaTeX examples,
  command tables, and setup snippets were already duplicated in
  `references/professional_report_formatting.md` and `assets/REPORT_FORMATTING_GUIDE.md`.
- The tail sections (References, Assets, Scope, Working Alongside Other Tools,
  Professional Reports vs. Journal Manuscripts, Venue-Specific Writing Styles) overlapped
  each other and were consolidated into "Choosing a Formatting Approach", "Bundled Files",
  and "Scope".

## 8. Packaged as a zip with the folder at the root

claude.ai requires a zip whose root is the skill folder, with the folder name matching the
skill name. The archive now contains `scientific-writing/` at its root rather than loose
files.

## Verified against the spec

| Requirement | Status |
|---|---|
| `name` present, <=64 chars, only `[a-z0-9-]` | pass (`scientific-writing`, 18) |
| `name` free of reserved words "anthropic"/"claude" | pass |
| `description` present, <=200 chars | pass (186) |
| No XML tags in `name` or `description` | pass |
| YAML frontmatter parses | pass |
| SKILL.md body under 5,000 tokens | pass (~4,800) |
| Every bundled file referenced by SKILL.md exists | pass (11/11) |
| Zip root is the skill folder | pass |

## Installing

**claude.ai** (Pro, Max, Team, Enterprise, with code execution enabled): Settings >
Capabilities, upload the zip, then enable the skill.

**Claude Code**: unzip into `~/.claude/skills/` for personal use or `.claude/skills/`
inside a project. No upload needed; Claude Code discovers `SKILL.md` automatically.

**Claude API**: upload through the `/v1/skills` endpoints. Note that API skill containers
have no network access, which does not affect this skill since it makes no network calls.

Skills do not sync across surfaces. Upload separately wherever you want it.

## A note on the frontmatter

`license`, `allowed-tools`, and `metadata` are optional fields. Spec-compliant runtimes
ignore frontmatter keys they do not recognize, and `allowed-tools` is honored by Claude
Code. The `metadata` block preserves upstream attribution to K-Dense Inc. and records that
this is a modified build.
