---
name: scientific-writing
description: Write scientific manuscripts as flowing prose. Covers IMRAD, abstracts, citations, figures, tables, CONSORT/STROBE/PRISMA. Use for research papers, journal submissions, reviewer replies.
license: MIT
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
metadata:
  skill-author: K-Dense Inc.
  upstream-version: 1.0.0
  modified: true
  modification-notes: "Local build. Removed vendor promotion, mandatory figure quotas, and references to non-bundled scripts and skills. Restructured for progressive disclosure. See CHANGES.md."
---
# Scientific Writing

## Overview

This skill covers how to write and structure scientific manuscripts. Claims in a manuscript should be backed by a literature search and citations verified against the original sources.

Scientific writing is a process for communicating research with precision and clarity. Write manuscripts using IMRAD structure, citations (APA/AMA/Vancouver), figures/tables, and reporting guidelines (CONSORT/STROBE/PRISMA). Apply this skill for research papers and journal submissions.

**Core principle: write the final manuscript in full paragraphs, not bullet points.** Use a two-stage process: first outline each section as key points, then convert the outline into complete paragraphs.

## When to Use This Skill

This skill should be used when:
- Writing or revising any section of a scientific manuscript (abstract, introduction, methods, results, discussion)
- Structuring a research paper using IMRAD or other standard formats
- Formatting citations and references in specific styles (APA, AMA, Vancouver, Chicago, IEEE)
- Creating, formatting, or improving figures, tables, and data visualizations
- Applying study-specific reporting guidelines (CONSORT for trials, STROBE for observational studies, PRISMA for reviews)
- Drafting abstracts that meet journal requirements (structured or unstructured)
- Preparing manuscripts for submission to specific journals
- Improving writing clarity, conciseness, and precision
- Ensuring proper use of field-specific terminology and nomenclature
- Addressing reviewer comments and revising manuscripts

## Figures and Visual Elements

Figures earn their place by showing something the text cannot: a spatial relationship, a
distribution, a workflow, a mechanism. Plan them alongside the data story rather than
adding them at the end.

**How many.** Follow the venue's limit, which is usually stricter than authors expect.
Nature allows 4-6 display items for a research article; Science allows 4-5; medical
journals typically 3-5; ML conference figures count against an 8-page limit. Absent a
stated limit, roughly one display item per 1000 words is a reasonable target. A few
well-designed figures beat many redundant ones, and reviewers do reject papers for
exceeding venue limits. See `references/figures_tables.md` for per-venue detail.

**Graphical abstracts.** Some venues want one, some ignore them, and a few prohibit them.
Cell Press journals and many Elsevier titles request one; Nature and most medical journals
do not. Check the author guidelines before making one.

**What tends to benefit from a diagram:**

- Study design and participant flow (CONSORT, PRISMA, STROBE diagrams — often required)
- Conceptual frameworks and hypothesized relationships
- Experimental workflows and analysis pipelines
- Biological pathways or proposed mechanisms
- System or model architectures
- Decision trees and algorithms

**What usually does not:** a definition, a two-group comparison that fits in one sentence,
or anything already stated precisely in a table.

Every figure needs a self-explanatory caption, defined abbreviations, stated sample sizes,
labeled axes with units, and an explanation of what the error bars represent. Check that
it still reads in grayscale and works for common color vision deficiencies.

---

## Core Capabilities

### 1. Manuscript Structure and Organization

**IMRAD Format**: Guide papers through the standard Introduction, Methods, Results, And Discussion structure used across most scientific disciplines. This includes:
- **Introduction**: Establish research context, identify gaps, state objectives
- **Methods**: Detail study design, populations, procedures, and analysis approaches
- **Results**: Present findings objectively without interpretation
- **Discussion**: Interpret results, acknowledge limitations, propose future directions

For detailed guidance on IMRAD structure, refer to `references/imrad_structure.md`.

**Alternative Structures**: Support discipline-specific formats including:
- Review articles (narrative, systematic, scoping)
- Case reports and case series
- Meta-analyses and pooled analyses
- Theoretical/modeling papers
- Methods papers and protocols

### 2. Section-Specific Writing Guidance

**Abstract Composition**: Craft concise, standalone summaries (100-250 words) that capture the paper's purpose, methods, results, and conclusions. Support both structured abstracts (with labeled sections) and unstructured single-paragraph formats.

**Introduction Development**: Build compelling introductions that:
- Establish the research problem's importance
- Review relevant literature systematically
- Identify knowledge gaps or controversies
- State clear research questions or hypotheses
- Explain the study's novelty and significance

**Methods Documentation**: Ensure reproducibility through:
- Detailed participant/sample descriptions
- Clear procedural documentation
- Statistical methods with justification
- Equipment and materials specifications
- Ethical approval and consent statements

**Results Presentation**: Present findings with:
- Logical flow from primary to secondary outcomes
- Integration with figures and tables
- Statistical significance with effect sizes
- Objective reporting without interpretation

**Discussion Construction**: Synthesize findings by:
- Relating results to research questions
- Comparing with existing literature
- Acknowledging limitations honestly
- Proposing mechanistic explanations
- Suggesting practical implications and future research

### 3. Citation and Reference Management

Apply citation styles correctly across disciplines. For comprehensive style guides, refer to `references/citation_styles.md`.

**Major Citation Styles:**
- **AMA (American Medical Association)**: Numbered superscript citations, common in medicine
- **Vancouver**: Numbered citations in square brackets, biomedical standard
- **APA (American Psychological Association)**: Author-date in-text citations, common in social sciences
- **Chicago**: Notes-bibliography or author-date, humanities and sciences
- **IEEE**: Numbered square brackets, engineering and computer science

**Best Practices:**
- Cite primary sources when possible
- Include recent literature (last 5-10 years for active fields)
- Balance citation distribution across introduction and discussion
- Verify all citations against original sources
- Use reference management software (Zotero, Mendeley, EndNote)

### 4. Figures and Tables

Create effective data visualizations that enhance comprehension. For detailed best practices, refer to `references/figures_tables.md`.

**When to Use Tables vs. Figures:**
- **Tables**: Precise numerical data, complex datasets, multiple variables requiring exact values
- **Figures**: Trends, patterns, relationships, comparisons best understood visually

**Design Principles:**
- Make each table/figure self-explanatory with complete captions
- Use consistent formatting and terminology across all display items
- Label all axes, columns, and rows with units
- Include sample sizes (n) and statistical annotations
- Follow the "one table/figure per 1000 words" guideline
- Avoid duplicating information between text, tables, and figures

**Common Figure Types:**
- Bar graphs: Comparing discrete categories
- Line graphs: Showing trends over time
- Scatterplots: Displaying correlations
- Box plots: Showing distributions and outliers
- Heatmaps: Visualizing matrices and patterns

### 5. Reporting Guidelines by Study Type

Ensure completeness and transparency by following established reporting standards. For comprehensive guideline details, refer to `references/reporting_guidelines.md`.

**Key Guidelines:**
- **CONSORT**: Randomized controlled trials
- **STROBE**: Observational studies (cohort, case-control, cross-sectional)
- **PRISMA**: Systematic reviews and meta-analyses
- **STARD**: Diagnostic accuracy studies
- **TRIPOD**: Prediction model studies
- **ARRIVE**: Animal research
- **CARE**: Case reports
- **SQUIRE**: Quality improvement studies
- **SPIRIT**: Study protocols for clinical trials
- **CHEERS**: Economic evaluations

Each guideline provides checklists ensuring all critical methodological elements are reported.

### 6. Writing Principles and Style

Apply fundamental scientific writing principles. For detailed guidance, refer to `references/writing_principles.md`.

**Clarity**:
- Use precise, unambiguous language
- Define technical terms and abbreviations at first use
- Maintain logical flow within and between paragraphs
- Use active voice when appropriate for clarity

**Conciseness**:
- Eliminate redundant words and phrases
- Favor shorter sentences (15-20 words average)
- Remove unnecessary qualifiers
- Respect word limits strictly

**Accuracy**:
- Report exact values with appropriate precision
- Use consistent terminology throughout
- Distinguish between observations and interpretations
- Acknowledge uncertainty appropriately

**Objectivity**:
- Present results without bias
- Avoid overstating findings or implications
- Acknowledge conflicting evidence
- Maintain professional, neutral tone

### 7. Writing Process: From Outline to Full Paragraphs

**Write the final manuscript in full paragraphs. Bullet points belong in the planning stage, not the submitted paper.**

Scientific papers must be written in complete, flowing prose. Use this two-stage approach for effective writing:

**Stage 1: Create Section Outlines with Key Points**

When starting a new section:
1. Gather relevant literature and data using whatever literature search tool is available
2. Create a structured outline with bullet points marking:
   - Main arguments or findings to present
   - Key studies to cite
   - Data points and statistics to include
   - Logical flow and organization
3. These bullet points serve as scaffolding—they are NOT the final manuscript

**Example outline (Introduction section):**
```
- Background: AI in drug discovery gaining traction
  * Cite recent reviews (Smith 2023, Jones 2024)
  * Traditional methods are slow and expensive
- Gap: Limited application to rare diseases
  * Only 2 prior studies (Lee 2022, Chen 2023)
  * Small datasets remain a challenge
- Our approach: Transfer learning from common diseases
  * Novel architecture combining X and Y
- Study objectives: Validate on 3 rare disease datasets
```

**Stage 2: Convert Key Points to Full Paragraphs**

Once the outline is complete, expand each bullet point into proper prose:

1. **Transform bullet points into complete sentences** with subjects, verbs, and objects
2. **Add transitions** between sentences and ideas (however, moreover, in contrast, subsequently)
3. **Integrate citations naturally** within sentences, not as lists
4. **Expand with context and explanation** that bullet points omit
5. **Ensure logical flow** from one sentence to the next within each paragraph
6. **Vary sentence structure** to maintain reader engagement

**Example conversion to prose:**

```
Artificial intelligence approaches have gained significant traction in drug discovery 
pipelines over the past decade (Smith, 2023; Jones, 2024). While these computational 
methods show promise for accelerating the identification of therapeutic candidates, 
traditional experimental approaches remain slow and resource-intensive, often requiring 
years of laboratory work and substantial financial investment. However, the application 
of AI to rare diseases has been limited, with only two prior studies demonstrating 
proof-of-concept results (Lee, 2022; Chen, 2023). The primary obstacle has been the 
scarcity of training data for conditions affecting small patient populations. 

To address this challenge, we developed a transfer learning approach that leverages 
knowledge from well-characterized common diseases to predict therapeutic targets for 
rare conditions. Our novel neural architecture combines convolutional layers for 
molecular feature extraction with attention mechanisms for protein-ligand interaction 
modeling. The objective of this study was to validate our approach across three 
independent rare disease datasets, assessing both predictive accuracy and biological 
interpretability of the results.
```

For the outline-versus-prose comparison, the limited cases where lists are acceptable, and
guidance on abstract format, see `references/writing_process.md`.

### 8. Professional Report Formatting (Non-Journal Documents)

For research reports, technical reports, white papers, and other professional documents
that are not journal manuscripts, use the `scientific_report.sty` LaTeX style package in
`assets/`. It provides Helvetica typography, a coordinated color scheme, nine colored box
environments (`keyfindings`, `methodology`, `resultsbox`, `recommendations`, `limitations`,
`criticalnotice`, `definition`, `executivesummary`, `hypothesis`), tables with alternating
row colors, and shortcut commands for p-values, effect sizes, and confidence intervals.

Compile with XeLaTeX or LuaLaTeX so Helvetica renders correctly:

```bash
xelatex report.tex
```

- `references/professional_report_formatting.md` — full guide with worked LaTeX examples
- `assets/REPORT_FORMATTING_GUIDE.md` — quick command reference
- `assets/scientific_report_template.tex` — complete template to copy

Do not use this style for journal manuscripts or conference papers; follow the venue's own
template instead.

### 9. Journal-Specific Formatting

Adapt manuscripts to journal requirements:
- Follow author guidelines for structure, length, and format
- Apply journal-specific citation styles
- Meet figure/table specifications (resolution, file formats, dimensions)
- Include required statements (funding, conflicts of interest, data availability, ethical approval)
- Adhere to word limits for each section
- Format according to template requirements when provided

### 10. Field-Specific Language and Terminology

Match the terminology of the target discipline: gene and species nomenclature, drug naming,
units, and the preferred term for study participants all vary by field, and getting them
wrong signals unfamiliarity to reviewers. See `references/field_terminology.md` for
conventions in biomedical, molecular biology, chemistry, ecology, physics, neuroscience,
and social science writing, plus guidance on defining terms for your audience.

### 11. Common Pitfalls to Avoid

**Top Rejection Reasons:**
1. Inappropriate, incomplete, or insufficiently described statistics
2. Over-interpretation of results or unsupported conclusions
3. Poorly described methods affecting reproducibility
4. Small, biased, or inappropriate samples
5. Poor writing quality or difficult-to-follow text
6. Inadequate literature review or context
7. Figures and tables that are unclear or poorly designed
8. Failure to follow reporting guidelines

**Writing Quality Issues:**
- Mixing tenses inappropriately (use past tense for methods/results, present for established facts)
- Excessive jargon or undefined acronyms
- Paragraph breaks that disrupt logical flow
- Missing transitions between sections
- Inconsistent notation or terminology

## Workflow for Manuscript Development

**Stage 1: Planning**
1. Identify target journal and review author guidelines
2. Determine applicable reporting guideline (CONSORT, STROBE, etc.)
3. Outline manuscript structure (usually IMRAD)
4. Plan figures and tables as the backbone of the paper

**Stage 2: Drafting** (Use two-stage writing process for each section)
1. Start with figures and tables (the core data story)
2. For each section below, follow the two-stage process:
   - **First**: Create an outline with bullet points, grounded in a literature search
   - **Second**: Convert bullet points to full paragraphs with flowing prose
3. Write Methods (often easiest to draft first)
4. Draft Results (describing figures/tables objectively)
5. Compose Discussion (interpreting findings)
6. Write Introduction (setting up the research question)
7. Craft Abstract (synthesizing the complete story)
8. Create Title (concise and descriptive)

**Remember**: Bullet points are for planning only—the final manuscript must be in complete paragraphs.

**Stage 3: Revision**
1. Check logical flow and "red thread" throughout
2. Verify consistency in terminology and notation
3. Ensure figures/tables are self-explanatory
4. Confirm adherence to reporting guidelines
5. Verify all citations are accurate and properly formatted
6. Check word counts for each section
7. Proofread for grammar, spelling, and clarity

**Stage 4: Final Preparation**
1. Format according to journal requirements
2. Prepare supplementary materials
3. Write cover letter highlighting significance
4. Complete submission checklists
5. Gather all required statements and forms

## Choosing a Formatting Approach

| Document Type | Formatting Approach |
|---------------|---------------------|
| Journal manuscripts | Journal author guidelines / supplied template |
| Conference papers | Official conference template |
| Research reports, white papers, technical and grant reports | `assets/scientific_report.sty` |

Venues differ sharply in what they expect — Nature and Science want accessible,
story-driven writing with broad significance; Cell Press wants mechanistic depth; NEJM and
The Lancet want structured abstracts and conservative evidence language; ML conferences
want numbered contributions and ablation studies. Apply the general principles above, then
read 3-5 recent papers from the target venue and match what they do. Where the two
disagree, the venue's own author guidelines win.

Each reference file has a "Venue-Specific" section covering these differences in structure,
citations, figures, reporting, and style.

## Bundled Files

**References** (read as needed):
- `imrad_structure.md` — IMRAD format and section-by-section content
- `citation_styles.md` — APA, AMA, Vancouver, Chicago, IEEE, ACS, NLM
- `figures_tables.md` — figure and table design, per-venue limits
- `reporting_guidelines.md` — CONSORT, STROBE, PRISMA and others, with checklists
- `writing_principles.md` — clarity, conciseness, accuracy, tense, common pitfalls
- `field_terminology.md` — discipline-specific nomenclature and vocabulary
- `writing_process.md` — extended outline-to-prose guidance and abstract format
- `professional_report_formatting.md` — report styling with worked LaTeX examples

**Assets**:
- `scientific_report.sty` — LaTeX style package for professional reports
- `scientific_report_template.tex` — complete template to copy
- `REPORT_FORMATTING_GUIDE.md` — quick command reference

## Scope

Everything this skill needs is bundled here. There are no external scripts to run and no
companion skills to install.

Two things sit outside that scope on purpose. **Literature search:** the two-stage process
assumes you can search the literature and verify citations against the original sources.
Use whatever search tool you have, and never cite a source you have not read. **Figure
rendering:** this skill covers what makes a figure publication-quality and how many a venue
accepts; producing the image files is a separate job.
