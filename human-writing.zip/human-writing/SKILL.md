---
name: human-writing
description: Write prose that reads as human-written rather than AI-generated. Combines ASD-STE100 Simplified Technical English for clarity, Zinsser's four principles for humanity, and a catalogue of AI writing tells to strip out. Use this skill whenever you draft or edit prose that a person will read — documentation, guides, explainers, READMEs, release notes, emails, reports, summaries, proposals, blog posts, slide text, UI copy — and whenever the user asks to rewrite, tighten, simplify, or de-AI existing text, including phrasings like "make this clearer", "does this sound like AI?", "tighten this up", "make it sound human", "/ste", or any mention of ASD-STE100 or Simplified Technical English. Default to using it for any writing deliverable of more than a few sentences, even if the user does not mention style. Do not use it for code, code comments, commit messages, config files, or structured data.
---

# Human writing

Your prose should read like a person wrote it on purpose. Two forces work against that:
AI writing habits, which are recognizable and are getting more recognizable, and
technical-writing sludge, which is recognizable and always has been.

This skill fixes both — but not with the same tool, and not at the same strength.

**Do not announce that you are using this skill.** Do not name the standard, explain the
style, or add a note about the register you chose. The output is the whole deliverable.

---

## Step 1 — Pick the register

ASD-STE100 is a safety harness. You wear it on the roof, not at dinner. It bans
metaphor, contractions, and varied sentence structure *on purpose*, because in a
maintenance manual those things kill people. Applied to a personal essay, the same rules
produce something dead.

So classify the text first. Everything downstream depends on this.

| The text's job | Register | STE applies |
|---|---|---|
| Steps a reader performs; safety notices; runbooks, install guides, API reference, config docs, spec, legal or regulated text | **locked** | Fully |
| Explaining, informing, persuading: documentation prose, README bodies, release notes, emails, reports, briefs, summaries, proposals, PR descriptions | **guided** ← default | Clarity subset only |
| Making someone feel, remember, or laugh: fiction, poetry, personal essays, jokes, marketing with voice, social posts with a point of view | **off** | Not at all |

Rules of thumb:

- **Unsure between locked and guided → guided.** Over-applying STE is the more common
  and more damaging error.
- **Mixed documents get classified section by section.** An install guide has locked
  steps and a guided introduction. A note inside a procedure is descriptive text, not
  procedural.
- **The user's explicit instruction always wins.** "/ste" or "use ASD-STE100" forces
  locked. "Make it fun" forces off.

### What each register means

**locked** — Full ASD-STE100. Read [references/ste-rules.md](./references/ste-rules.md) before drafting. Sentence
caps (20 words procedural, 25 descriptive), approved vocabulary only, imperative
instructions, active voice, no contractions, no semicolons, no phrasal verbs, one name
per thing.

**guided** — STE's discipline without its costume. Keep: short sentences, active voice,
one word per concept used consistently, actions as verbs not nouns, conditions before
commands, no Latin abbreviations, no fog. Drop: the approved word list, the contraction
ban, the ban on metaphor and idiom, the uniform sentence cap. This is where most work
lands.

**off** — No STE. Sentence length, vocabulary, metaphor, and rhythm are all yours. Step 2
still applies in full.

---

## Step 2 — Always on, every register

### Kill the AI tells

[references/ai-tells.md](./references/ai-tells.md) has all 27 with examples and fixes. These are the highest-signal
ones — check every draft against them from memory, then run the script in Step 4.

1. **"That's not X. That's Y."** → Say the second half only.
2. **Two fragments stapled together.** "Fast. Simple." → Pick one.
3. **Double image, no instruction.** "Less a hammer, more a scalpel." → Say what to do.
4. **Self-applause.** "And that matters." "That's the part everyone misses." → Delete.
   You lose nothing.
5. **"It's the X of Y."** → Only works if the reader knows both. Describe what it does.
6. **Throat-clearing.** "Here's the thing." "The truth is." → Start one sentence later.
7. **Always three.** "Faster, cheaper, smarter." → Count the real reasons. It is often
   two, sometimes five.
8. **Ranges.** "5 to 10 minutes" means nobody measured. → Give the number, or say you
   do not know.
9. **Recap endings.** "In short…" → Stop typing.
10. **Flagged vocabulary.** delve, leverage, crucial, robust, seamless, tapestry,
    comprehensive, "in today's fast-paced world." One is nothing; four is a signature.
11. **Uniform sentence length.** The strongest structural tell and the least noticed.
    Generated prose clusters at 15-20 words per sentence. Human prose swings.
12. **Adjectives standing in for numbers.** "significantly faster" → "3.2x faster."
13. **No concrete anchors.** No names, dates, versions, or prices anywhere in the piece.
14. **Fake balance.** Every claim neutralized by a counterweight, so nothing is asserted.

### Add the humanity

STE gives you Zinsser's first three principles — Simplicity, Brevity, Clarity — and
actively works against the fourth. Put **Humanity** back deliberately:

- **One concrete anchor per section.** A version number, a date, a name, a real
  measurement. This is the cheapest and strongest human signal available.
- **Take a position.** Say what you actually think. "I'd skip this library" beats "there
  are tradeoffs to consider."
- **Admit the limit.** Name what does not work, what you did not test, what you do not
  know. "I don't know" is a legitimate sentence.
- **Vary the rhythm on purpose.** Put a four-word sentence after a thirty-word one.
- **Contractions** in guided and off. They are how people talk.
- **Cut the applause.** Trust the reader to notice what mattered.

---

## Step 3 — Draft

Write the thing. Apply the register's rules as you go rather than writing loose prose and
cleaning it afterward — retrofitted STE reads like retrofitted STE.

For **locked**, read [references/ste-rules.md](./references/ste-rules.md) and [references/word-swaps.md](./references/word-swaps.md) (List A)
first. For **guided**, [references/word-swaps.md](./references/word-swaps.md) (List B) is enough. For **off**, neither
is needed.

When a word swap breaks the grammar, rebuild the sentence rather than forcing the
substitution (rule 9.1). "The oil level must be visible" does not become "must be see";
it becomes "Make sure that you can see the oil level."

---

## Step 4 — Check before you deliver

Run the checker. It catches the mechanical tells and, more usefully, reports the sentence
length spread that you cannot eyeball.

```bash
python3 scripts/check_draft.py DRAFT.md --register guided
python3 scripts/check_draft.py DRAFT.md --register locked --type procedural
```

No dependencies beyond the Python standard library. If you cannot execute code, do the
same passes by eye against [references/ai-tells.md](./references/ai-tells.md).

**Read the findings as prompts, not verdicts.** A deliberate choice that trips a check is
still a deliberate choice. False positives are expected and are cheaper than misses.

Then do these three by hand, because no regex catches them:

1. **Does it say anything?** Strip the applause and the hedging and see if a claim
   survives. If not, the problem is the thinking, not the prose.
2. **Is there one real detail?** A number, a name, a date. If the whole piece could
   describe any product at any company, it describes nothing.
3. **Would you send it?** Read it as the recipient. Stiff, evasive, or smug means go
   back to Step 1 — usually the register is wrong.

---

## Reference files

| File | Read it when |
|---|---|
| [references/ai-tells.md](./references/ai-tells.md) | Always. All 27 patterns, with examples and fixes. Also the instructions for growing it — add every new tell you catch. |
| [references/ste-rules.md](./references/ste-rules.md) | Locked register, or any time a specific STE rule is in question. All 9 sections plus the general recommendations, paraphrased from Issue 9 with rule numbers. |
| [references/word-swaps.md](./references/word-swaps.md) | List A for locked (verified against the Issue 9 dictionary). List B for every register. |
| [references/examples.md](./references/examples.md) | Unsure how hard to apply a rule, or a rewrite came out stiff. Includes the same content written in all three registers, and the four common failure modes. |
| [scripts/check_draft.py](./scripts/check_draft.py) | Every draft, at Step 4. |

---

## What not to touch

Code blocks, commands, file paths, error strings, quoted UI text, quoted speech, API
identifiers, and proper nouns stay exactly as written. This skill governs the prose
around them.

Never alter a direct quotation to fit the style.

---

## Boundaries

- **Never claim certified STE compliance.** [references/ste-rules.md](./references/ste-rules.md) is a paraphrase and
  the word lists are a working subset. Certified aerospace or defense deliverables need
  the official ASD specification and human sign-off.
- **Do not flatten someone else's voice.** When editing text a user wrote themselves,
  remove the tells and keep their phrasing. If a cut would change what they are saying
  rather than how, flag it instead of making it.
- **If the user asks why a change was made,** answer plainly and name the pattern. The
  ban on announcing the skill covers unsolicited narration, not honest answers.
