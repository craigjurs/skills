#!/usr/bin/env python3
"""
check_draft.py — flags AI writing tells and STE violations in a draft.

Usage:
    python3 check_draft.py DRAFT.md
    python3 check_draft.py DRAFT.md --register locked --type procedural
    cat draft.txt | python3 check_draft.py -

Registers:
    off      anti-AI-tell checks only (creative writing)
    guided   anti-AI-tell checks + plain-English checks   [default]
    locked   everything, plus full ASD-STE100 checks

Every finding is a prompt to look, not a verdict. False positives are expected and
are cheaper than missed tells. Judgment stays with the writer.

Exit code is always 0. This is a report, not a gate.
"""

import argparse
import re
import statistics
import sys

# ---------------------------------------------------------------- text handling

FENCE = re.compile(r"^\s*(```|~~~)")


def load(path):
    """Return list of (line_number, text) with fenced code blocks removed."""
    if path == "-":
        raw = sys.stdin.read()
    else:
        with open(path, encoding="utf-8") as fh:
            raw = fh.read()
    out, in_fence = [], False
    for n, line in enumerate(raw.split("\n"), 1):
        if FENCE.match(line):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        out.append((n, line))
    return out


def prose_only(line):
    """Strip inline code, URLs, and markdown markers so they do not trip regexes."""
    line = re.sub(r"`[^`]*`", " CODE ", line)
    line = re.sub(r"https?://\S+", " URL ", line)
    line = re.sub(r"^\s{0,3}#{1,6}\s+", "", line)
    line = re.sub(r"^\s*[-*+]\s+", "", line)
    line = re.sub(r"^\s*\d+[.)]\s+", "", line)
    return line


SENT_END = re.compile(r"(?<=[.!?:])\s+(?=[A-Z0-9\"'(])")
NEW_BLOCK = re.compile(r"^\s*(?:#{1,6}\s|[-*+]\s|\d+[.)]\s|>|\||\s*$)")


def blocks(lines):
    """Group wrapped lines into logical blocks.

    Markdown hard-wraps a paragraph across several lines. Treating each line as a
    unit would chop sentences in half and destroy the sentence-length statistic,
    which is the whole point of the rhythm check. A new block starts at a blank
    line, a heading, a list item, a quote, or a table row.
    """
    out, buf, start = [], [], None
    for n, line in lines:
        if NEW_BLOCK.match(line):
            if buf:
                out.append((start, " ".join(buf)))
                buf, start = [], None
            if line.strip():                      # heading / list item / quote
                out.append((n, prose_only(line).strip()))
            continue
        text = prose_only(line).strip()
        if not text:
            continue
        if start is None:
            start = n
        buf.append(text)
    if buf:
        out.append((start, " ".join(buf)))
    return [(n, t) for n, t in out if t]


def sentences(units):
    """Yield (line_number, sentence). Colons end sentences per STE rule 8.4."""
    for n, text in units:
        for s in SENT_END.split(text):
            s = s.strip()
            if s:
                yield n, s


def ste_wordcount(sentence):
    """Approximate ASD-STE100 rules 8.5-8.7.

    Counts as one word each: a parenthetical group, a quoted string, a number with
    its unit, an abbreviation, an alphanumeric identifier, a hyphenated word.
    """
    s = re.sub(r"\([^)]*\)", " X ", sentence)          # 8.5
    s = re.sub(r"\"[^\"]*\"|'[^']*'", " X ", s)         # 8.6 quoted text
    s = re.sub(r"\b\d[\d,.]*\s*[a-zA-Z%°]+\b", " X ", s)  # 8.6 number + unit
    s = re.sub(r"\b[\w]+(?:-[\w]+)+\b", " X ", s)       # 8.7 hyphenated
    return len([w for w in re.findall(r"[\w'X]+", s) if w])


# ---------------------------------------------------------------- pattern tables
# (regex, label, fix)

TELLS_STRUCTURE = [
    (r"\b(?:it'?s|that'?s|this is)\s+not\s+(?:just\s+)?[^.;!?]{2,45}[.;—–-]\s*(?:it'?s|that'?s|this is)\b",
     "negation-flip (tell 1)", "say the second half only"),
    (r"\b(?:is|are|was|were)n'?t\s+(?:about\s+)?[^.;!?]{2,45}[.;—–-]\s*(?:it'?s|they'?re|that'?s)\b",
     "negation-flip (tell 1)", "say the second half only"),
    (r"\bnot only\b[^.!?]{2,60}\bbut also\b",
     "not-only-but-also (tell 1)", "make the claim once"),
    (r"\b(?:less (?:a|like a)|more (?:a|like a))\s+\w+,\s*(?:more|less)\s+(?:a|like a)?\s*\w+",
     "double-image with no instruction (tell 3)", "say what to do"),
    (r"(?:^|[.!?]\s)(?:And |But )?(?:that|this|which|it)\s+(?:matters|is exactly the point|is the point|changes everything)\b",
     "self-applause (tell 4)", "delete"),
    (r"\bthat'?s the part (?:everyone|most people|nobody)\b",
     "self-applause (tell 4)", "delete"),
    (r"\bhere'?s why that (?:matters|is|'s a big deal)\b",
     "self-applause (tell 4)", "delete"),
    (r"\b(?:it'?s|think of it as|basically)\s+the\s+\w+\s+of\s+\w+",
     "the-X-of-Y analogy (tell 5)", "describe what it does"),
    (r"(?:^|[.!?]\s)\s*(?:Here'?s the thing|Let me be clear|The truth is|Look,|Let'?s be honest|The reality is|Let'?s dive in|Here'?s what)\b",
     "throat-clearing (tell 6)", "start one sentence later"),
    (r"\b\d+\s*(?:to|-|–|—)\s*\d+\s*(?:seconds|minutes|hours|days|weeks|months|percent|%|x|times|lines)\b",
     "range instead of a number (tell 8)", "give the real number, or admit you don't know"),
    (r"(?:^|[.!?]\s)\s*(?:In short|In conclusion|In summary|At the end of the day|To sum up|All in all|The bottom line|Ultimately)\b",
     "recap ending (tell 9)", "stop typing"),
]

TELLS_VOCAB = [
    (r"\b(?:delve|leverag(?:e|es|ed|ing)|harness(?:es|ed|ing)?|foster(?:s|ed|ing)?|underscore[sd]?|"
     r"spearhead(?:s|ed|ing)?|embark(?:s|ed|ing)?)\b", "flagged verb (tell 10)", "use the plain verb"),
    (r"\b(?:tapestry|realm|treasure trove|game-?changer|deep dive|myriad|plethora|cornerstone|testament)\b",
     "flagged noun (tell 10)", "name the actual thing"),
    (r"\b(?:crucial|pivotal|robust|seamless|comprehensive|holistic|intricate|nuanced|multifaceted|"
     r"meticulous|cutting-edge|ever-evolving|invaluable)\b", "flagged adjective (tell 10)",
     "delete it, or replace with a fact"),
    (r"\bin (?:today'?s|an era of|a world of)\b", "stock opener (tell 10)", "delete the clause"),
    (r"\b(?:can|may|might|could)\s+(?:potentially|possibly)\b", "stacked hedge (tell 11)", "one hedge maximum"),
    (r"\bit(?:'?s| is) (?:worth|important to) (?:not(?:e|ing)|mention(?:ing)?)\b",
     "worth-noting frame (tell 12)", "delete the frame"),
    (r"\b(?:powerful|intuitive|flexible|scalable|efficient|elegant),\s+(?:\w+),?\s+and\s+\w+\b",
     "adjective stack (tell 13)", "replace with one fact"),
]

TELLS_SUBSTANCE = [
    (r"\b(?:significantly|dramatically|substantially|considerably|vastly)\s+"
     r"(?:faster|slower|better|worse|more|less|improved|reduced|increased)\b",
     "adjective standing in for a number (tell 18)", "give the number"),
    (r"\bwhile\s+[^,.]{3,40}\s+is\s+(?:powerful|useful|great|helpful)[^.]{0,40}\b(?:it'?s not|it is not)\b",
     "fake balance (tell 20)", "take the position, or name the real limit"),
    (r"\b(?:not a silver bullet|isn'?t for everyone|your mileage may vary|there'?s no one-size-fits-all)\b",
     "fake balance (tell 20)", "name the specific condition instead"),
    (r"\b(?:the possibilities are endless|sky'?s the limit|only limited by your imagination|"
     r"unlock(?:ing)? (?:new|its full) potential)\b", "uplift ending (tell 21)", "end on the last real point"),
]

TELLS_CONVERSATIONAL = [
    (r"(?:^|[.!?]\s)\s*(?:Great|Excellent|Good|Fantastic|Interesting) question\b",
     "sycophantic opener (tell 24)", "answer"),
    (r"(?:^|[.!?]\s)\s*(?:Absolutely!|Certainly!|Of course!|I'?d be happy to)\b",
     "sycophantic opener (tell 24)", "answer"),
    (r"\bwould you like me to\b[^.?]{0,60}\bor\b[^.?]{0,60}\?",
     "menu of next steps (tell 26)", "offer one, or none"),
]

PLAIN_ENGLISH = [
    (r"\bin order to\b", "wordy", "to"),
    (r"\bdue to the fact that\b", "wordy", "because"),
    (r"\bin the event (?:that|of)\b", "wordy", "if"),
    (r"\bat this point in time\b", "wordy", "now"),
    (r"\bprior to\b", "wordy", "before"),
    (r"\bsubsequent to\b", "wordy", "after"),
    (r"\ba large number of\b", "wordy", "many"),
    (r"\bthe majority of\b", "wordy", "most"),
    (r"\bhas the ability to\b", "wordy", "can"),
    (r"\bwith regard to\b", "wordy", "about"),
    (r"\b(?:perform|conduct|carry out)\s+(?:an?\s+)?\w+(?:sis|tion|ment|ing)\b",
     "nominalization", "use the verb directly"),
    (r"\b(?:make|reach)\s+a\s+(?:decision|agreement|determination)\b",
     "nominalization", "decide / agree"),
    (r"\bis indicative of\b", "nominalization", "shows"),
]

STE_CHECKS = [
    (r";", "semicolon (rule 8.1)", "write two sentences"),
    (r"\b\w+'(?:s|t|re|ve|ll|d|m)\b(?!\s*(?:s\b))", "contraction (rule 4.2)", "write it out"),
    (r"\b(?:should|would|could|may|might)\b", "modal (dictionary)", "must / can / will"),
    (r"\b(?:has|have|had)\s+been\b", "perfect tense (rule 3.4)", "simple past"),
    (r"\b(?:has|have|had)\s+\w+ed\b", "perfect tense (rule 3.4)", "simple past"),
    (r"\b(?:is|are|was|were)\s+being\b", "continuous passive (rule 3.4)", "simple active form"),
    (r"\b(?:is|are|was|were|am)\s+(?!being\b)\w+ing\b", "continuous tense (rule 3.5)",
     "simple present or past"),
    (r"\b(?:e\.g\.|i\.e\.|etc\.)", "Latin abbreviation (GR-6)", "for example / that is / finish the list"),
    (r"\bmake sure (?!that\b)(?:the|a|an|this|these|you|it)\b", "missing 'that' (GR-1)", "make sure that ..."),
    (r"\b(?:he|she|his|her|him|hers)\b", "gendered pronoun (GR-7)", "rewrite gender-neutral"),
    (r"\b(?:carry out|set up|put out|give off|find out|go down|go up|take off)\b",
     "phrasal verb (rule 9.3)", "single approved verb"),
    (r"\bthere (?:is|are)\s+\w+", "empty subject", "give the sentence a real subject"),
    (r"\b(?:utilize|ensure|verify|perform|obtain|facilitate|terminate|commence|initiate|"
     r"accomplish|acquire|modify|alter|retain|rotate|indicate|via|toxic|comprise|"
     r"eliminate|implement|provide|require|significant|various|visible|acceptable)\b",
     "unapproved word (section 1)", "see references/word-swaps.md list A"),
]

STE_LOCAL = [
    (r"\b(?:above|below)\s+\d", "above/below used for a quantity (rule 9.2)", "more than / less than"),
    (r"\b(?:check|test|work|damage)\s+the\b", "noun used as a verb (rule 1.2)",
     "do a check of / do a test of / do work / cause damage to"),
    (r"\bfollow (?:the |these )?(?:steps|instructions|procedure)", "wrong meaning of 'follow' (rule 1.3)", "obey"),
]


# ---------------------------------------------------------------- check runners

def scan(units, table, findings, bucket):
    for n, text in units:
        for pattern, label, fix in table:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                findings.append((bucket, n, label, m.group(0).strip()[:60], fix))


def check_fragment_pairs(units, findings):
    """Tell 2: two consecutive very short sentences."""
    seq = list(sentences(units))
    for i in range(len(seq) - 1):
        (n1, s1), (n2, s2) = seq[i], seq[i + 1]
        w1, w2 = len(s1.split()), len(s2.split())
        if w1 <= 3 and w2 <= 3 and s1[-1:] in ".!?" and s2[-1:] in ".!?":
            findings.append(("STRUCTURE", n1, "fragment pair (tell 2)",
                             f"{s1} {s2}"[:60], "pick one, or write the full sentence"))


def check_triads(units, findings):
    """Tell 7: three single-word items in a list."""
    for n, text in units:
        for m in re.finditer(r"\b(\w+),\s+(\w+),?\s+and\s+(\w+)\s*[.!?]", text):
            if all(len(g) > 2 for g in m.groups()):
                findings.append(("STRUCTURE", n, "possible triad (tell 7)", m.group(0)[:60],
                                 "count the real reasons — is the third load-bearing?"))


def check_parallelism(units, findings):
    """Tell 16: three consecutive sentences opening with the same two words."""
    seq = list(sentences(units))
    for i in range(len(seq) - 2):
        heads = [" ".join(s.split()[:2]).lower() for _, s in seq[i:i + 3]]
        if len(set(heads)) == 1 and len(heads[0]) > 3:
            findings.append(("RHYTHM", seq[i][0], "perfect parallelism (tell 16)",
                             heads[0], "vary the construction"))


def check_bold_bullets(lines, findings):
    hits = [n for n, l in lines if re.match(r"^\s*[-*+]\s+\*\*[^*]+\*\*\s*[:—-]", l)]
    if len(hits) >= 4:
        findings.append(("RHYTHM", hits[0], f"{len(hits)} identical bolded bullet lead-ins (tell 17)",
                         "", "let the bullets differ in shape and length"))


def check_em_dashes(units, findings):
    total_words = sum(len(t.split()) for _, t in units)
    dashes = [n for n, t in units for _ in re.finditer(r"—|--", t)]
    if total_words and len(dashes) / total_words > 0.006 and len(dashes) >= 3:
        findings.append(("RHYTHM", dashes[0],
                         f"{len(dashes)} em dashes in {total_words} words (tell 27)",
                         "", "keep them for real parenthesis, not for drama"))


def check_specificity(units, findings):
    """Tell 19: no concrete anchors anywhere."""
    body = " ".join(t for _, t in units)
    numbers = len(re.findall(r"\b\d+\b", body))
    propers = len(re.findall(r"(?<![.!?]\s)(?<!^)\b[A-Z][a-z]{2,}\b", body))
    words = len(body.split())
    if words > 120 and numbers < 2 and propers < 3:
        findings.append(("SUBSTANCE", 1, "no concrete anchors (tell 19)",
                         f"{numbers} numbers, {propers} proper nouns in {words} words",
                         "add a version, a date, a name, a real number"))


def rhythm_report(units, cap):
    seq = [(n, s) for n, s in sentences(units)]
    lengths = [len(s.split()) for _, s in seq]
    over = [(n, ste_wordcount(s), s) for n, s in seq if cap and ste_wordcount(s) > cap]
    if len(lengths) < 4:
        # Too few sentences for the spread statistic to mean anything, but the
        # per-sentence cap still applies.
        return None, over
    mean = statistics.mean(lengths)
    sd = statistics.pstdev(lengths)
    return (len(lengths), mean, sd, min(lengths), max(lengths)), over


# ---------------------------------------------------------------- output

BUCKET_ORDER = ["STRUCTURE", "VOCAB", "RHYTHM", "SUBSTANCE", "CONVERSATIONAL",
                "PLAIN ENGLISH", "STE"]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", help="draft file, or - for stdin")
    ap.add_argument("--register", choices=["off", "guided", "locked"], default="guided")
    ap.add_argument("--type", choices=["procedural", "descriptive", "auto"], default="auto",
                    help="sets the STE sentence cap: 20 words procedural, 25 descriptive")
    args = ap.parse_args()

    lines = load(args.path)
    units = blocks(lines)
    if not units:
        print("Nothing to check (file is empty or all code).")
        return

    findings = []
    scan(units, TELLS_STRUCTURE, findings, "STRUCTURE")
    scan(units, TELLS_VOCAB, findings, "VOCAB")
    scan(units, TELLS_SUBSTANCE, findings, "SUBSTANCE")
    scan(units, TELLS_CONVERSATIONAL, findings, "CONVERSATIONAL")
    check_fragment_pairs(units, findings)
    check_triads(units, findings)
    check_parallelism(units, findings)
    check_bold_bullets(lines, findings)
    check_em_dashes(units, findings)
    check_specificity(units, findings)

    if args.register in ("guided", "locked"):
        scan(units, PLAIN_ENGLISH, findings, "PLAIN ENGLISH")
    if args.register == "locked":
        scan(units, STE_CHECKS, findings, "STE")
        scan(units, STE_LOCAL, findings, "STE")

    cap = None
    if args.register == "locked":
        cap = 20 if args.type == "procedural" else 25
    stats, over = rhythm_report(units, cap)

    print("=" * 72)
    print(f"  DRAFT CHECK — register: {args.register}" + (f", cap: {cap} words" if cap else ""))
    print("=" * 72)

    if stats:
        count, mean, sd, lo, hi = stats
        print(f"\nRHYTHM  {count} sentences | mean {mean:.1f} words | "
              f"spread (sd) {sd:.1f} | shortest {lo} | longest {hi}")
        if sd < 5:
            print("        ⚠  Spread below 5 — sentences are too uniform (tell 14).")
            print("           Break one long sentence; fuse two short ones.")
        else:
            print("        ✓  Sentence length varies.")

    if over:
        print(f"\nOVER CAP  {len(over)} sentence(s) exceed {cap} STE words:")
        for n, wc, s in over[:12]:
            print(f"   L{n:<4} {wc} words: {s[:66]}")

    if findings:
        print(f"\n{len(findings)} pattern(s) to review:\n")
        for bucket in BUCKET_ORDER:
            rows = [f for f in findings if f[0] == bucket]
            if not rows:
                continue
            print(f"  {bucket}")
            seen = set()
            for _, n, label, snippet, fix in sorted(rows, key=lambda r: r[1]):
                key = (n, label, snippet)
                if key in seen:
                    continue
                seen.add(key)
                shown = f'"{snippet}"' if snippet else ""
                print(f"   L{n:<4} {label}")
                if shown:
                    print(f"          {shown}")
                print(f"          → {fix}")
            print()
    else:
        print("\nNo flagged patterns.")

    print("-" * 72)
    print("Findings are prompts to look, not verdicts. A deliberate choice that trips")
    print("a check is still a deliberate choice — keep it and move on.")


if __name__ == "__main__":
    main()
