#!/usr/bin/env bash
# install.sh — copy the human-writing skill into every agent that reads SKILL.md.
#
#   ./install.sh                 install everywhere this machine supports
#   ./install.sh claude cursor   install only to the named targets
#   ./install.sh --project       use project-scoped paths (run from your repo root)
#   ./install.sh --list          show the paths without copying
#
# Targets: claude, cursor, copilot, codex, cline, roo, windsurf, opencode,
#          agents (vendor-neutral), all
#
# Databricks is not handled here — the workspace filesystem is remote.
# See README-INSTALL.md for the databricks CLI command.

set -euo pipefail

SKILL_NAME="human-writing"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT=0
DRY=0
TARGETS=()

for arg in "$@"; do
  case "$arg" in
    --project) PROJECT=1 ;;
    --list|--dry-run) DRY=1 ;;
    -h|--help) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "Unknown flag: $arg" >&2; exit 1 ;;
    *) TARGETS+=("$arg") ;;
  esac
done

if [ ${#TARGETS[@]} -eq 0 ] || [ "${TARGETS[0]}" = "all" ]; then
  TARGETS=(claude cursor copilot codex cline roo windsurf opencode agents)
fi

if [ ! -f "$SRC/SKILL.md" ]; then
  echo "Error: SKILL.md not found in $SRC" >&2
  echo "Run this script from inside the $SKILL_NAME folder." >&2
  exit 1
fi

path_for() {
  case "$1" in
    claude)   [ $PROJECT -eq 1 ] && echo ".claude/skills"   || echo "$HOME/.claude/skills" ;;
    cursor)   [ $PROJECT -eq 1 ] && echo ".cursor/skills"   || echo "$HOME/.cursor/skills" ;;
    copilot)  [ $PROJECT -eq 1 ] && echo ".github/skills"   || echo "$HOME/.copilot/skills" ;;
    codex)    [ $PROJECT -eq 1 ] && echo ".codex/skills"    || echo "$HOME/.codex/skills" ;;
    cline)    [ $PROJECT -eq 1 ] && echo ".cline/skills"    || echo "$HOME/.cline/skills" ;;
    roo)      [ $PROJECT -eq 1 ] && echo ".roo/skills"      || echo "$HOME/.roo/skills" ;;
    windsurf) [ $PROJECT -eq 1 ] && echo ".windsurf/skills" || echo "$HOME/.windsurf/skills" ;;
    opencode) [ $PROJECT -eq 1 ] && echo ".opencode/skills" || echo "$HOME/.opencode/skills" ;;
    agents)   [ $PROJECT -eq 1 ] && echo ".agents/skills"   || echo "$HOME/.agents/skills" ;;
    *) return 1 ;;
  esac
}

installed=0
for t in "${TARGETS[@]}"; do
  if ! dir="$(path_for "$t")"; then
    echo "  skip   $t (unknown target)"
    continue
  fi
  dest="$dir/$SKILL_NAME"

  if [ $DRY -eq 1 ]; then
    printf "  %-8s %s\n" "$t" "$dest"
    continue
  fi

  mkdir -p "$dir"
  rm -rf "$dest"
  mkdir -p "$dest"

  # Copy the skill itself, not the installer or any local scratch files.
  for item in SKILL.md references scripts; do
    [ -e "$SRC/$item" ] && cp -R "$SRC/$item" "$dest/"
  done
  [ -f "$dest/scripts/check_draft.py" ] && chmod +x "$dest/scripts/check_draft.py"

  printf "  %-8s %s\n" "$t" "$dest"
  installed=$((installed + 1))
done

if [ $DRY -eq 1 ]; then
  echo
  echo "(dry run — nothing copied)"
  exit 0
fi

echo
echo "Installed to $installed location(s)."
echo
echo "Next steps:"
echo "  Claude Code   start a new session, then ask: what skills do you have?"
echo "  Cursor        reload the window, then check Customize -> Skills"
echo "  VS Code       type /skills in Copilot chat to confirm it is listed"
echo
echo "Skill metadata is read once at session start. Restart before testing."
