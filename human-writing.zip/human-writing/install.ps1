<#
.SYNOPSIS
    Installs the human-writing skill into every agent harness that reads SKILL.md.

.DESCRIPTION
    Copies this skill folder into each agent's skills directory. Personal scope
    (the default) applies to every project you open. Project scope applies only to
    the repository you run it from, and travels to teammates through git.

.PARAMETER Targets
    Which agents to install to. Default is all of them.
    Valid: claude, cursor, copilot, codex, cline, roo, windsurf, opencode, agents

.PARAMETER Project
    Use project-scoped paths instead of personal. Run from your repository root.

.PARAMETER List
    Show the destination paths without copying anything.

.EXAMPLE
    .\install.ps1
    Install to all harnesses, personal scope. Applies to every project.

.EXAMPLE
    .\install.ps1 -List
    Preview the paths first.

.EXAMPLE
    .\install.ps1 -Targets copilot,claude,agents
    Install only to the three locations VS Code searches.

.EXAMPLE
    .\install.ps1 -Project
    Install into the current repository so teammates get it via git.

.NOTES
    Databricks is not handled here - that workspace filesystem is remote.
    Import human-writing-databricks.zip through the workspace UI instead.
#>

[CmdletBinding()]
param(
    [ValidateSet('claude', 'cursor', 'copilot', 'codex', 'cline',
                 'roo', 'windsurf', 'opencode', 'agents', 'all')]
    [string[]]$Targets = @('all'),

    [switch]$Project,
    [switch]$List
)

$ErrorActionPreference = 'Stop'
$SkillName = 'human-writing'
$Src = $PSScriptRoot

if (-not (Test-Path (Join-Path $Src 'SKILL.md'))) {
    Write-Error "SKILL.md not found in $Src. Run this script from inside the $SkillName folder."
    exit 1
}

if ($Targets -contains 'all') {
    $Targets = @('claude', 'cursor', 'copilot', 'codex', 'cline',
                 'roo', 'windsurf', 'opencode', 'agents')
}

# Personal paths live under the user profile. Project paths are relative to the
# current directory, which must be the repository root.
$PersonalRoot = $env:USERPROFILE
$Map = @{
    claude   = @{ personal = '.claude\skills';   project = '.claude\skills'   }
    cursor   = @{ personal = '.cursor\skills';   project = '.cursor\skills'   }
    copilot  = @{ personal = '.copilot\skills';  project = '.github\skills'   }
    codex    = @{ personal = '.codex\skills';    project = '.codex\skills'    }
    cline    = @{ personal = '.cline\skills';    project = '.cline\skills'    }
    roo      = @{ personal = '.roo\skills';      project = '.roo\skills'      }
    windsurf = @{ personal = '.windsurf\skills'; project = '.windsurf\skills' }
    opencode = @{ personal = '.opencode\skills'; project = '.opencode\skills' }
    agents   = @{ personal = '.agents\skills';   project = '.agents\skills'   }
}

$scope = if ($Project) { 'project' } else { 'personal' }
Write-Host ""
Write-Host "  Installing '$SkillName'  (scope: $scope)" -ForegroundColor Cyan
Write-Host ""

$count = 0
foreach ($t in $Targets) {
    $leaf = $Map[$t][$scope]
    $dir  = if ($Project) { Join-Path (Get-Location) $leaf } else { Join-Path $PersonalRoot $leaf }
    $dest = Join-Path $dir $SkillName

    if ($List) {
        '  {0,-9} {1}' -f $t, $dest | Write-Host
        continue
    }

    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    New-Item -ItemType Directory -Path $dest -Force | Out-Null

    # Copy the skill itself, never the installers or local scratch files.
    foreach ($item in @('SKILL.md', 'references', 'scripts')) {
        $path = Join-Path $Src $item
        if (Test-Path $path) { Copy-Item $path -Destination $dest -Recurse -Force }
    }

    '  {0,-9} {1}' -f $t, $dest | Write-Host -ForegroundColor Green
    $count++
}

if ($List) {
    Write-Host ""
    Write-Host "  (preview only - nothing copied)" -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "  Installed to $count location(s)." -ForegroundColor Cyan
Write-Host ""
Write-Host "  Next: quit VS Code completely and reopen it. Skill metadata is read"
Write-Host "  once at startup, so a window reload is not always enough."
Write-Host ""
Write-Host "  Then type / in the chat input and look for $SkillName."
Write-Host ""
