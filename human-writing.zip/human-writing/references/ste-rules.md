# ASD-STE100 Simplified Technical English — working rule reference

Paraphrased from ASD-STE100 Issue 9 (January 2025), Part 1 "Writing rules". Rule numbers
match the specification so you can look up the authoritative wording. The examples here
are written for this reference, not copied from the standard.

**What this is not:** the official specification. The full spec and its ~2,900-entry
approved dictionary are copyright ASD (Aerospace, Security and Defence Industries
Association of Europe). This file encodes the *rules*; it does not reproduce the
*dictionary*. For certified aerospace or defense deliverables you need the official
document from asd-ste100.org plus human sign-off. Never claim certified compliance.

**Where this applies:** the **locked** register only, and the clarity subset of it in
**guided**. See SKILL.md for the register router.

---

## Contents

| Section | Covers | Rules |
|---|---|---|
| [1](#section-1--words) | Which words you may use | 1.1 - 1.14 |
| [2](#section-2--multi-word-nouns) | Noun clusters | 2.1 - 2.2 |
| [3](#section-3--verbs) | Verb forms, tense, voice | 3.1 - 3.7 |
| [4](#section-4--sentences) | Sentence structure, lists, articles | 4.1 - 4.5 |
| [5](#section-5--procedural-writing) | Instructions | 5.1 - 5.5 |
| [6](#section-6--descriptive-writing) | Explanation | 6.1 - 6.6 |
| [7](#section-7--safety-instructions) | Warnings and cautions | 7.1 - 7.3 |
| [8](#section-8--punctuation-and-word-count) | Punctuation, how to count words | 8.1 - 8.7 |
| [9](#section-9--writing-practices) | Rewriting, phrasal verbs, consistency | 9.1 - 9.4 |
| [GR](#general-recommendations) | General recommendations | GR-1 - GR-8 |

**The first decision, before any rule applies:** is this text **procedural** (steps a
reader performs) or **descriptive** (information a reader absorbs)? Sections 5 and 6
diverge sharply. A mixed document is classified section by section, and a note inside a
procedure is descriptive text.

---

## Section 1 — Words

**1.1** Use three kinds of word only: words approved in the STE dictionary, technical
nouns, and technical verbs. Everything else gets replaced.

**1.2** Use an approved word only as its listed part of speech. `work` is approved as a
noun, not a verb — so "when you work with solvents" becomes "when you do work with
solvents." `damage` is a noun, so "do not damage the seal" becomes "do not cause damage
to the seal."

**1.3** Use an approved word only with its approved meaning. Many common words are
approved in a narrow sense and forbidden in their everyday sense:

| Word | Approved sense | So this is wrong |
|---|---|---|
| wear | to erode by friction | "wear protective gloves" → "put on protective gloves" |
| turn | to move around an axis | "the indicator turns green" → "the color of the indicator changes to green" |
| see | to perceive with the eyes | "see if it is tight" → "make sure that it is tight" |
| above / below | physical position | "below 20 psi" → "less than 20 psi" |
| follow | to come after | "follow these steps" → "obey these steps" |
| fall | to move down under gravity | "the pressure falls" → "the pressure decreases" |

**1.4** Use only the verb and adjective forms the dictionary lists. Adjectives get their
comparative and superlative forms from the dictionary (`slow / slower / slowest`), or
from `more` and `most`, which are approved.

**1.5 - 1.11 (technical nouns)** A technical noun is a name for a thing in your domain
that the general dictionary cannot supply: part names, tool names, product names, UI
labels, materials, units. You may use them freely, subject to:

- **1.6** — a word not in the dictionary is permitted *only* as a technical noun or part
  of one. This is the escape hatch; it is not a loophole for ordinary vocabulary.
- **1.7** — do not verb a technical noun. "Bearing the load" is not licensed by the part
  called a bearing.
- **1.8** — use technical nouns your company, industry, or field has actually approved.
- **1.9** — where you have a choice, pick the shorter, plainer name.
- **1.10** — no regional words, slang, or in-house jargon.
- **1.11** — one item, one name, forever. Never rotate synonyms for elegance. If it is
  the `retaining collar` in step 2, it is not the `retainer` in step 7.

**1.12 - 1.13 (technical verbs)** Domain verbs your field genuinely needs (drill, ream,
weld, calibrate; in software: compile, boot, deploy, index) are permitted. Do not turn
them back into nouns — "do a deploy" is wrong, "deploy the build" is right.

**1.14** American English spelling, unless a directive says otherwise. Do not change the
spelling inside quoted text.

---

## Section 2 — Multi-word nouns

**2.1** Maximum three words in a noun cluster. `overhead panel light` is at the limit.
`main gear door retraction winch handle` is not English, it is a compression artifact —
the reader has to guess which word modifies which.

**2.2** When a technical noun genuinely runs longer than three words, write it in full
once, then either define a short form or hyphenate the words that act as a single unit:
`main-gear-door retraction-winch handle`.

The general repair, and usually the better one, is to decompose with prepositions:

| Cluster | Decomposed |
|---|---|
| Runway light connection resistance calibration | Calibration of the resistance of the runway light connection |
| Engine transmission housing attachment bolts | The bolts that attach the transmission housing to the engine |
| User authentication token refresh failure | A failure to refresh the user authentication token |

---

## Section 3 — Verbs

**3.1** Only the verb forms the dictionary gives.

**3.2** Only these forms and tenses:
- infinitive
- imperative (the command form)
- simple present
- simple past
- simple future
- past participle, used as an adjective

**3.3** The past participle is permitted **as an adjective** — `the removed panel`, `a
damaged seal` — not as part of a compound tense.

**3.4** No auxiliary verbs building compound constructions. This kills the perfect and
continuous tenses outright:

| Not this | This |
|---|---|
| We have received the report. | We received the report. |
| The system is being tested. | We test the system. / The test is in progress. |
| It has been running since 2019. | It started to operate in 2019. |
| The valve had been closed. | Someone closed the valve. |

**3.5** An `-ing` word is allowed **only** inside a technical noun (`the mounting
bracket`, `logging level`). Never as a verb, never as a gerund subject. "Installing the
driver requires admin rights" → "You must have admin rights to install the driver."

**3.6** Active voice. Passive is permitted only in descriptive text, and only when the
agent is genuinely unknown.

**3.7** An action is a verb, not a noun. This is the single highest-yield rule for
ordinary business prose:

| Not this | This |
|---|---|
| perform a compression of the log files | compress the log files |
| carry out an inspection of the seal | examine the seal |
| provide assistance to the operator | help the operator |
| make a decision | decide |

---

## Section 4 — Sentences

**4.1** Short, clear sentences. Instructions go directly to the reader in the imperative.
A long compound instruction becomes a numbered list of short ones.

**4.2** Do not shorten by deleting words. Two specific bans:

- **No dropped articles.** "Remove the bolt and stop" is genuinely ambiguous — is `stop`
  a second part or a command? "Remove the bolt and the stop" is not.
- **No contractions.** "don't touch" → "do not touch". A contraction is fine English and
  a real cost to a non-native reader scanning under time pressure.

**4.3** Use a vertical list when a sentence would otherwise carry many items or actions.
The conventions:
- colon at the end of the lead-in line
- each item starts with a capital letter
- an article before the noun in each item, where applicable
- a period only if the item is a full sentence — and always a period on the last item
- never a comma or semicolon at line ends
- do not mix procedural and descriptive items in one list
- in safety lists, repeat `DO NOT` on each item rather than hoisting it into the lead-in

**4.4** Connect related sentences with connecting words: `and`, `but`, `then`, `thus`,
`as a result`, `at the same time`. STE explicitly permits starting a sentence with `And`
or `But`. This is the rule that stops STE prose from turning into a telegram, and it is
the one most often forgotten.

**4.5** Put an article (`the`, `a`, `an`) or a demonstrative (`this`, `these`) in front of
nouns and noun clusters. Headline-style compression — "Insert pin in bracket" — is
forbidden.

---

## Section 5 — Procedural writing

**5.1** **Maximum 20 words per sentence.** Warnings and cautions obey this too.

**5.2** One instruction per sentence. Two actions share a sentence only when they
genuinely happen at the same time.

**5.3** Instructions in the imperative. Not "the panel should be opened," not "you must
open the panel" — "Open the panel."

**5.4** When the reader needs to know a condition first, the condition goes first,
separated by a comma: "If the pressure decreases, close the valve." Never "Close the
valve if the pressure decreases" — by the time the condition arrives, the reader has
already started closing the valve.

**5.5** A note gives information. A note never gives an instruction. If you find an
imperative inside a note, it belongs in a numbered step.

---

## Section 6 — Descriptive writing

**6.1** Release information gradually, one subject per sentence. Descriptive text does
not use the imperative.

**6.2** Use key words and key phrases to give the text a visible logical structure.

**6.3** **Maximum 25 words per sentence.**

**6.4** Paragraphs group related information.

**6.5** One topic per paragraph.

**6.6** **Maximum six sentences per paragraph.**

---

## Section 7 — Safety instructions

Definitions: a **warning** signals risk of injury or death. A **caution** signals risk of
damage to equipment. Other schemes (`DANGER`, `NOTICE`) are fine if they obey 7.1-7.3.

**7.1** Label the level of risk explicitly.

**7.2** Open with the command or the condition — never with the hazard.

**7.3** Then explain the risk or the consequence.

The ordering matters more than it looks. A reader skimming under stress acts on the first
clause they read:

| Not this | This |
|---|---|
| Touching the terminal can cause electrocution. | WARNING: DO NOT TOUCH THE TERMINAL. THE TERMINAL HAS A DANGEROUS VOLTAGE. |
| Data loss may occur if --force is used in production. | CAUTION: DO NOT USE THE --force FLAG ON THE PRODUCTION DATABASE. THE FLAG DELETES THE ROWS THAT DO NOT MATCH THE SOURCE. |

---

## Section 8 — Punctuation and word count

**8.1** All standard English punctuation is permitted **except the semicolon**. Write two
sentences.

**8.2** Hyphens connect words that operate as one unit.

**8.3** Parentheses are permitted for: references to figures or text, item numbers and
letters, work-step identifiers, abbreviations, singular/plural pairs, short
explanations, and alternatives.

**8.4** In a vertical list, a colon ends a sentence for counting purposes, the same as a
period.

**8.5** Everything inside a pair of parentheses counts as **one** word.

**8.6** Each of these counts as **one** word: a number; a number with its unit; an
abbreviation; an alphanumeric identifier; quoted text; a title, heading, placard, or
label; a proper noun naming a person, group, organization, or country.

**8.7** A hyphenated word counts as one word.

*Practical effect:* `Set the pressure to 24.5 psi (see figure 3) and label it "MAIN".`
counts as roughly 9 words, not 14. The caps are less restrictive than they appear.

---

## Section 9 — Writing practices

**9.1** When a word-for-word swap does not work, rebuild the sentence. Four cases force
this: the replacement needs different grammar; the swap produces nonsense; the swap
changes the meaning; or the word is not in the dictionary at all.

> "The oil level must be visible during the test."
> `visible` is not approved; `see` is. But `see` is a verb, so the sentence has to change
> shape: "During the test, make sure that you can see the oil level."

The failure mode to avoid is mechanical substitution that leaves grammatical wreckage.
Read the result as a sentence, not as a diff.

**9.2** Use each approved word in its approved meaning and part of speech — the
enforcement rule behind 1.2 and 1.3. See the table in Section 1.

**9.3** **No phrasal verbs.** A verb plus a preposition forms a new unit whose meaning
does not follow from its parts, which is precisely what a non-native reader cannot
decode. Both halves being approved words does not make the pair approved.

| Phrasal | Single verb |
|---|---|
| put out (a fire) | extinguish |
| give off (fumes) | release |
| go down (pressure) | decrease |
| set up | install, assemble |
| carry out | do |
| find out | learn, discover |
| turn on / turn off | *(these two are approved; they are the standard power-state verbs)* |

**9.4** One consistent style for terminology and wording throughout a document set.

---

## General recommendations

**GR-1 — keep the conjunction "that."** Native speakers drop it; non-native readers need
it to find where the main clause ends. "Make sure the valve is open" → "Make sure **that**
the valve is open."

**GR-2 — watch "with."** It carries three approved senses (association, assistance,
instrument) and produces real ambiguity. "Install the panel with the green fasteners" has
three readings. Rewrite to pick one. Also, keep the *primary action* as the main verb:
not "Use tool TS9867 to seal the opening" but "Seal the opening with tool TS9867."

**GR-3 — pronouns must have exactly one possible referent.** "If you engage the pins
incorrectly with the seats, they can become damaged" — which? Replace the pronoun with
the noun.

**GR-4 — "this" needs a visible antecedent.** "Make sure the cover is not locked (this can
cause damage)" — does the locking cause damage, or the unlocking? Restate the condition.

**GR-5 — false friends.** Words that look like a word in the reader's language but mean
something else. Italian *disposizione* is not English *disposition*.

**GR-6 — no Latin abbreviations.** `e.g.` → `for example`. `i.e.` → `that is`. `etc.` →
finish the list, or delete it.

**GR-7 — inclusive, gender-neutral language.** No `he` or `she`; neither is in the
dictionary. Avoid `man` and `woman` unless the context requires them medically.

**GR-8 — possessives are permitted but risky.** `the manufacturer's instructions` is fine.
Many languages have no equivalent construction, so if you are not certain the sentence is
correct, rewrite it: `the instructions from the manufacturer`.

---

## The five checks that catch most violations

If you only have time for five passes over a locked-register draft:

1. Any sentence over 20 words (procedural) or 25 (descriptive), counting per 8.5-8.7
2. Compound verb tenses — search for `has`, `have`, `had`, `is being`, `was being`
3. `-ing` used as a verb
4. Missing articles, and missing `that` after `make sure` / `show` / `recommend`
5. The same object called by two different names
