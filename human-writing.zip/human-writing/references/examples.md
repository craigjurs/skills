# Worked examples

Read this when you are unsure how hard to apply a rule, or when a rewrite feels stiff.

- [The same content in all three registers](#the-same-content-in-all-three-registers)
- [Locked register](#locked-register)
- [Guided register](#guided-register)
- [Off register](#off-register)
- [Rhythm repair](#rhythm-repair)
- [Failure modes](#failure-modes)

---

## The same content in all three registers

One fact, three jobs. This is the whole skill in one example.

**The fact:** the deploy script needs an environment variable set, and forgetting it
wipes the staging database.

### Locked — a runbook step

> CAUTION: SET THE `TARGET_ENV` VARIABLE BEFORE YOU RUN THE DEPLOY SCRIPT. IF THE
> VARIABLE IS NOT SET, THE SCRIPT DELETES THE STAGING DATABASE.
>
> 1. Set the `TARGET_ENV` variable to `staging` or `production`.
> 2. Run the deploy script.
> 3. Make sure that the output shows the correct environment.

Command first, then the risk (rule 7.2). One instruction per step (rule 5.2). No
contractions (rule 4.2). Every sentence under 20 words (rule 5.1).

### Guided — the README section

> Set `TARGET_ENV` before you run `deploy.sh`. If you don't, the script defaults to
> staging and drops the database on the way in — which is exactly as bad as it sounds,
> and has happened twice.
>
> Valid values are `staging` and `production`. There is no dry-run flag yet.

Contractions are back. Sentence lengths vary from 5 words to 28. One concrete anchor
("twice") does more for credibility than any adjective would. Still no hedging, still
active voice, still no throat-clearing.

### Off — an incident retro post

> I dropped the staging database on a Tuesday afternoon because I forgot one
> environment variable, and then I did it again three weeks later.
>
> The second time is the interesting one. I knew about the trap. I had personally
> written the warning in the README. I just typed `./deploy.sh` on autopilot, the way
> you sign your name without reading the form.

Voice, an admission, an analogy that actually carries meaning. No STE at all. But note
what is still absent: no "here's the thing," no "and that matters," no triad, no recap
ending.

---

## Locked register

### Procedural rewrite

**Before** (one 47-word sentence, passive, hedged, condition buried):

> You should check that the reservoir has been filled with the correct fluid and, after
> attaching a clear tube to the bleed screw while ensuring its free end is submerged,
> the pedal can be pumped and held so that opening the screw releases trapped air.

**After:**

> 1. Fill the reservoir with the correct fluid.
> 2. Attach a clear tube to the bleed screw.
> 3. Put the free end of the tube in a container of fluid.
> 4. Push the pedal three times. Hold the pedal down.
> 5. Open the bleed screw one half turn. Air and fluid flow into the tube.
> 6. Close the bleed screw. Release the pedal.
> 7. If air continues to come out, do steps 4 thru 6 again.

Note step 7: the condition comes first (rule 5.4). Note steps 4-6: two short sentences
rather than one compound one (rule 5.2).

### Verb forms

| Before | After |
|---|---|
| We have received the reports. | We received the reports. |
| The service is being restarted. | The service restarts. |
| This has been in use since 2019. | We started to use this in 2019. |
| The screws should be replaced. | Replace the screws. |
| Installing the driver requires admin rights. | You must have admin rights to install the driver. |
| Ensure file exists before running. | Make sure that the file exists before you run the command. |

That last one shows three rules at once: `ensure` is unapproved, the articles were
dropped (rule 4.2), and `that` was omitted (GR-1).

### Noun clusters

| Before | After |
|---|---|
| Main gear door retraction winch handle | Main-gear-door retraction-winch handle |
| User authentication token refresh failure | A failure to refresh the user authentication token |
| Remove the engine transmission housing attachment bolts. | Remove the bolts that attach the transmission housing to the engine. |

### Safety instructions

| Before | After |
|---|---|
| Touching the terminal could result in electrocution. | WARNING: DO NOT TOUCH THE TERMINAL. THE TERMINAL HAS A DANGEROUS VOLTAGE. |
| Note that data loss may occur if --force is used against production. | CAUTION: DO NOT USE THE `--force` FLAG ON THE PRODUCTION DATABASE. THE FLAG DELETES THE ROWS THAT DO NOT MATCH THE SOURCE. |

The second one also fixes a rule 5.5 violation: the original buried an instruction
inside a note.

---

## Guided register

This is the default and the one you will use most. STE's discipline, ordinary English's
warmth.

### A documentation paragraph

**Before:**

> It's worth noting that the caching layer is a crucial component of the system
> architecture. It can potentially help to significantly reduce latency in many cases.
> This isn't just an optimization — it's a fundamental design decision.

**After:**

> The cache sits between the API and Postgres. On the read-heavy endpoints it cuts p99
> latency from about 400 ms to 60 ms; on writes it does nothing at all, which surprises
> people. We would not remove it, but it is not load-bearing for correctness.

Four tells removed (worth-noting frame, flagged adjective, stacked hedge, negation-flip)
and replaced with two real numbers and an honest limit.

### An email

**Before:**

> Hi team, I wanted to reach out regarding the Q3 timeline. Here's the thing: we're
> facing some challenges. The deadline isn't realistic. It's aspirational. Let me know
> if you have any questions!

**After:**

> Hi team — the Q3 date does not work. Integration testing alone needs three weeks and
> we scheduled one. I would like to move the launch to 12 November. If there is a reason
> that date is worse than shipping something half-tested, tell me and I will rethink it.

Throat-clearing gone, negation-flip gone, empty sign-off gone. A date, a number, and a
position appear in their place. The em dash survives because it is doing real
grammatical work.

### A release note

**Before:**

> This release delivers a comprehensive set of powerful improvements to the export
> pipeline, streamlining your workflow and unlocking new possibilities.

**After:**

> CSV export no longer times out on files over 50 MB. It streams to disk instead of
> buffering in memory, so peak RAM stays flat at about 200 MB regardless of file size.
> Excel export is unchanged and still slow — that fix is next.

---

## Off register

STE is switched off. The tells are not.

### What over-applying STE does to creative writing

**A poem, with STE applied:**

> The night is dark. The stars have light. I look at them. This makes me calm.

That is not simple, it is dead. Rhythm, metaphor, subordinate clauses, and ambiguity are
the *tools* of this register, and STE bans all four on purpose because they are hazards
in a maintenance manual.

**The rule:** if the text's job is to make someone feel something, remember something, or
laugh, register is `off`. Sentence caps, the approved word list, the contraction ban, and
the no-metaphor rule all lift.

### What still applies in the off register

| Still forbidden | Because |
|---|---|
| "That's not X. That's Y." | It is a rhetorical free lunch in any genre |
| Self-applause | The reader decides what mattered |
| Triads by default | Reality rarely gives you exactly three |
| Ranges instead of numbers | "5 to 10 minutes" is a confession |
| Recap endings | The reader just read it |
| Flagged vocabulary | `delve` and `tapestry` read as machine-written everywhere |
| Uniform sentence length | The strongest structural tell there is |

---

## Rhythm repair

Tell 14 is the hardest to see and the most worth fixing. Both passages below are clean
of every other tell. Only the rhythm differs.

**Uniform (standard deviation 2.1):**

> The parser reads the file line by line. It builds a token list as it goes. Each token
> carries a type and a position. The lexer hands these tokens to the parser stage. The
> parser then constructs the abstract syntax tree.

**Varied (standard deviation 9.4):**

> The parser reads the file line by line, building a token list as it goes and tagging
> each token with a type and a source position so later stages can produce error
> messages that point at something real. Then the lexer hands off. The tree gets built
> in one pass.

Same information. The second one has a 41-word sentence, a 5-word sentence, and a 7-word
sentence. Run `scripts/check_draft.py` to get the actual number for your draft.

---

## Failure modes

Things that go wrong when applying this skill. Watch for all four.

### 1. Mechanical substitution

Swapping a word without repairing the grammar around it (rule 9.1).

> "The oil level must be visible."
> ❌ "The oil level must be see."
> ✓ "Make sure that you can see the oil level."

Read the result as a sentence, not as a diff.

### 2. Stripping tells without replacing the thought

Deleting "and that matters" is correct. Deleting it and leaving the paragraph pointless
is not. If removing the applause reveals that there was no point, write the point.

### 3. Anti-tell overcorrection

Avoiding every flagged word so hard that the prose becomes evasive. `crucial` is a real
English word. One instance is nothing. The tell is the *cluster*.

Same for triads: sometimes there really are three things. Rule 7 says do not default to
three, not that three is banned.

### 4. Register drift in long documents

An installation guide that starts locked and drifts chatty by section 5. Classify each
section, and if a document genuinely mixes registers, say so at the top of the draft and
keep the boundaries clean.
