# AI tells — the forbidden patterns file

Every pattern here is a habit that reads as machine-written. Check every draft against
this file. The fix column is not optional: deleting a tell without replacing the
underlying thought just leaves a hole.

Patterns 1-9 come from Ruben Hassid's list. Patterns 10-27 extend it. Section
"Your own catches" at the bottom is where this file grows — see "How to grow this file."

---

## Contents

- [Structure tells (1-9)](#structure-tells)
- [Vocabulary tells (10-13)](#vocabulary-tells)
- [Rhythm tells (14-17)](#rhythm-tells)
- [Substance tells (18-23)](#substance-tells)
- [Conversational tells (24-27)](#conversational-tells)
- [How to grow this file](#how-to-grow-this-file)
- [Your own catches](#your-own-catches)

---

## Structure tells

### 1. The negation-flip: "That's not X. That's Y."

> That's not compliance. That's stalling.

The first half exists only to make the second half feel earned. It is a rhetorical
free lunch. Real writers just make the claim.

**Fix:** Say the second half only. "They're stalling."

**Variants that count as the same tell:** "It isn't X — it's Y." / "This isn't about
X. It's about Y." / "Not just X, but Y." / "Less X, more Y."

### 2. Two-word fragment pairs

> Fast. Simple.
> No fluff. Just answers.

Two stubs stapled together to fake emphasis. One stub is a stylistic choice. Two in a
row is a machine imitating a stylistic choice.

**Fix:** Pick one, or write the full sentence.

### 3. The double-image with no instruction

> Less a hammer, more a scalpel.

Two pictures, zero guidance. The reader now has to convert your metaphor back into
advice, which is the work you were supposed to do.

**Fix:** Say what to do. "Change one function at a time."

### 4. Self-applause

> And that matters.
> That's the part everyone misses.
> Which is exactly the point.
> Here's why that's a big deal.

The text clapping for itself. If the point landed, the reader knows. If it did not,
telling them it mattered will not fix it.

**Fix:** Delete. You lose nothing.

### 5. The "It's the X of Y" analogy

> It's the Excel of AI agents.

This only works if the reader knows both things well. Usually they know one. Often
neither.

**Fix:** Describe what it does. Keep the analogy only if the anchor is genuinely
universal and the mapping is exact.

### 6. Throat-clearing

> Here's the thing.
> Let me be clear.
> The truth is.
> Look —
> Let's be honest.

Warming up in front of the reader. The real sentence is always the next one.

**Fix:** Start one sentence later.

### 7. Always three things

> Faster, cheaper, smarter.

Three is the rhythm a language model reaches for when it does not know how many
things there are. Reality gives you two reasons, or five, or one.

**Fix:** Count the real reasons and give that many. If there truly are three, keep
three — but check that the third one is load-bearing and not filler.

### 8. Ranges instead of numbers

> It takes 5 to 10 minutes.
> This can improve performance by 20-40%.

A range means nobody measured. It is a hedge dressed as data.

**Fix:** Give the real number. "Seven minutes." If you genuinely do not know, say you
do not know — that is more honest than a fake interval.

### 9. The recap ending

> In short…
> At the end of the day…
> The bottom line is…

A summary of a piece the reader just finished reading.

**Fix:** Stop typing. End on the last real point.

---

## Vocabulary tells

### 10. The flagged word list

These words are not banned English. They are words that appear far more often in
generated text than in human text, so a cluster of them reads as machine-written.

**Verbs:** delve, leverage, harness, unlock, elevate, streamline, empower, foster,
underscore, navigate (figurative), embark, unpack (figurative), spearhead

**Nouns:** tapestry, realm, landscape (figurative), journey (figurative), testament,
cornerstone, treasure trove, game-changer, deep dive, myriad, plethora

**Adjectives:** crucial, pivotal, robust, seamless, comprehensive, holistic, intricate,
nuanced, multifaceted, meticulous, cutting-edge, ever-evolving, vital, invaluable

**Openers:** "In today's fast-paced world," "In an era of," "As we navigate,"
"Now more than ever"

**Fix:** Use the plain word. `leverage` → `use`. `crucial` → `important`, or delete the
adjective and let the noun carry it. One flagged word in a page is nothing. Four is a
signature.

### 11. Stacked hedges

> This can potentially help to significantly improve results in many cases.

Four hedges in one sentence. Each one individually is defensible. Together they mean
the writer is not willing to claim anything.

**Fix:** One hedge maximum, and only where the uncertainty is real. "This usually
cuts render time by half."

### 12. "It's worth noting that"

> It's important to note that the API rate-limits at 100 requests per minute.

If it were not worth noting you would not be writing it.

**Fix:** Delete the frame. "The API rate-limits at 100 requests per minute."

### 13. Adjective stacking

> a powerful, intuitive, and flexible framework

Three adjectives that each mean "good." None of them tell the reader anything they can
act on.

**Fix:** Replace with one fact. "It runs in 40 ms and has no config file."

---

## Rhythm tells

### 14. Uniform sentence length

The single strongest structural tell, and the one most people never look for. Generated
prose clusters tightly around 15-20 words per sentence. Human prose swings — a 34-word
sentence that builds an argument, then a four-word one that lands it.

**Fix:** After drafting, measure. If the standard deviation of your sentence lengths is
below about 5 words, break one long sentence in half and fuse two short ones. Aim for a
spread, not an average. (`scripts/check_draft.py` reports this number.)

**Note for locked register:** STE caps sentence length at 20 or 25 words. It does not
require every sentence to *be* 20 words. A four-word step next to a nineteen-word one is
fully STE-compliant and reads far better.

### 15. Uniform paragraph length

Every paragraph three sentences long, every section the same depth. Real documents are
lumpy: some ideas need six sentences, some need one.

**Fix:** Let at least one paragraph be a single sentence. Let one run long.

### 16. Perfect parallelism

> You get faster builds. You get smaller bundles. You get better caching.

Three sentences with identical grammar. It is a chant, not an argument.

**Fix:** Vary the construction. Or merge into one sentence with a real list.

### 17. Bolded bullet lead-ins, every bullet identical

> - **Speed:** It is fast.
> - **Cost:** It is cheap.
> - **Scale:** It handles load.

The template shows through. Rigid symmetry across every item means the content was
poured into a shape rather than the shape emerging from the content.

**Fix:** Use the bold lead-in only where a label genuinely helps navigation. Let bullets
be different lengths. Some bullets are a fragment; some are three sentences.

---

## Substance tells

### 18. Adjectives standing in for numbers

> significantly faster, dramatically reduced, a substantial improvement

**Fix:** The number, or nothing. "3.2x faster." If you do not have the number, say the
direction and admit the gap: "faster, though I haven't benchmarked it."

### 19. No proper nouns, no dates, no versions

Generated text floats free of the world. Human text is full of specific things: a
library version, a date, a person's name, a file path, a price.

**Fix:** Add at least one concrete anchor per section. Real detail is the cheapest and
strongest humanity signal there is.

### 20. Fake balance

> While X is powerful, it's not a silver bullet.
> X has its place, but it's not for everyone.

Every claim immediately neutralized by a counterweight, so the piece ends up asserting
nothing. This is different from real caveats, which name a specific condition.

**Fix:** Either take the position, or name the actual limit: "X breaks down above about
10,000 rows."

### 21. The uplift ending

> With the right approach, the possibilities are endless.

An inspirational close that adds no information and commits to nothing.

**Fix:** End on the last concrete thing you have to say. A piece is allowed to end
abruptly.

### 22. Everything at one altitude

Every paragraph pitched at the same level of abstraction — all principle, or all detail,
never a principle immediately grounded in one specific case.

**Fix:** After each general claim, drop one level: give the instance that made you
believe it.

### 23. No position, no risk, no mess

Nothing the writer might be wrong about. No "I think," no "this part is ugly," no
admission of what was not tried.

**Fix:** Say what you actually think. Name the thing that does not work. "I don't know"
is a legitimate and very human sentence.

---

## Conversational tells

*(These apply when the writing is a reply to a person, not a standalone document.)*

### 24. Sycophantic openers

> Great question!
> Absolutely!
> I'd be happy to help with that!

**Fix:** Answer.

### 25. Restating the question before answering

> You're asking about how to configure the timeout. Configuring the timeout is…

**Fix:** Start with the answer.

### 26. Offering three next steps at the end of everything

> Would you like me to (a) expand this, (b) rewrite it, or (c) provide examples?

**Fix:** Offer one, if one is genuinely useful. Otherwise stop.

### 27. Punctuation as drama

The em dash was the classic tell, so it got trained out and the habit moved house. Watch
for the same theatrical pause wearing a different mark: a colon before a one-word
payoff, a semicolon splicing two dramatic halves, or a lone ellipsis for suspense.

**Fix:** The tell is not the mark, it is the theatrical pause. Em dashes are good
punctuation used sparingly and for real parenthesis. If a mark is there for drama rather
than for grammar, cut it. Roughly one em dash per few hundred words is unremarkable;
one per paragraph is a signature.

---

## How to grow this file

This file is meant to get better every week. When you catch a pattern in a draft that is
not listed here:

1. Add it under "Your own catches" below.
2. Write it in the same shape as the entries above: the pattern, one real example you
   actually saw, and the fix.
3. Date it. Patterns drift as models change — an entry from two years ago may be dead.

If an entry stops firing for six months, delete it. A checklist nobody trusts gets
skipped entirely.

---

## Your own catches

<!-- Add new patterns here. Format:

### YYYY-MM-DD — Short name of the pattern

> The example you caught, verbatim.

Why it reads as machine-written.

**Fix:** What to do instead.

-->

*(empty — add your first catch here)*
