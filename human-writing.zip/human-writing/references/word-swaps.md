# Word swaps

Two lists that do different jobs. Do not mix them up.

- **List A** is STE vocabulary. It applies in the **locked** register only. Verified
  against the ASD-STE100 Issue 9 dictionary (January 2025).
- **List B** is the plain-English list. It applies in **every** register, including
  creative writing, because these swaps make prose better regardless of standard.

Neither list is the official dictionary, which has roughly 2,900 entries and is
copyright ASD. These are the entries that come up most in technical and business
writing. For anything certified, look the word up in the official specification.

---

## List A — STE vocabulary (locked register only)

### Unapproved → approved

| Do not use | Use |
|---|---|
| acceptable | permitted |
| accessible | *(rewrite)* "you can get access to" |
| accomplish | do |
| acquire, obtain, procure | get |
| additional, supplementary | more |
| adequate | sufficient |
| alter, modify | change |
| appropriate, relevant | applicable |
| ascertain, ensure, verify, validate | make sure (that) |
| assist, facilitate | help |
| attempt | try |
| avoid, prohibit | prevent |
| capable | can |
| cease, terminate | stop |
| commence, initiate | start |
| comprise | have, contain |
| conduct, execute, perform, implement | do |
| consider | think |
| construct | assemble |
| depress (a button) | push |
| determine, locate | find |
| eliminate | remove |
| employ, utilize | use |
| enable, permit | let |
| evaluate | examine |
| fabricate | make |
| feasible | possible |
| impact (as a verb) | hit |
| indicate | show |
| maintain, retain | keep |
| observe | monitor |
| provide | give, supply |
| proceed | continue |
| reduce | decrease |
| require | *(rewrite)* "is necessary" / "must" |
| rotate | turn |
| significant | important |
| toxic | poisonous |
| various | different |
| via | through |
| visible | *(rewrite)* "you can see" |

### Approved words that trip people up

These **are** approved, so do not "correct" them. But they are approved in one narrow
sense, and the everyday sense is forbidden.

| Word | Approved as | Approved meaning | Wrong use → right use |
|---|---|---|---|
| check | noun only | the procedure you do to make sure something works | "check the valve" → "do a check of the valve" |
| test | noun only | the procedure that measures something | "test the system" → "do a test of the system" |
| work | noun only | what you do | "work with solvents" → "do work with solvents" |
| damage | noun only | the result of an accident | "do not damage the seal" → "do not cause damage to the seal" |
| help | verb only | to make something easier | "with the help of" → "with the aid of" |
| aid | noun only | help that is given | — |
| close | verb only | to move together | "close to the edge" → "near the edge" |
| near | adjective | at a short distance | — |
| follow | verb | to come after | "follow these steps" → "obey these steps" |
| obey | verb | to do what an instruction says | — |
| monitor | verb | to check at intervals | replaces "observe" |
| examine | verb | to look at carefully | replaces "inspect", "evaluate" |
| turn | verb | to move around an axis | "the light turns red" → "the color changes to red" |
| decrease | verb | to become less | "the pressure falls/goes down" → "the pressure decreases" |
| level | adj + noun | horizontal / a measured height | a documented exception to one-part-of-speech |
| flush | adj + verb | surfaces touching / to clean with flow | a documented exception |

### Corrections to older word lists

Issue 9 changed some of these. If you are working from a list written before January
2025, it may tell you to replace words that are now approved:

- **approximately** — approved (adverb). Do not replace it.
- **sufficient** — approved (adjective). Do not replace it with "enough."
- **activate** and **deactivate** — approved (verbs), in the restricted sense of making a
  system ready or not ready for operation. For other senses use `start` and `stop`.
- **necessary**, **permitted**, **applicable**, **poisonous**, **monitor** — all approved.

### Function words

| Pattern | Fix |
|---|---|
| should, would, could, may, might | requirement → **must**; possibility → **can**; future → **will** |
| e.g. | for example |
| i.e. | that is |
| etc. | finish the list, or delete |
| he, she | rewrite gender-neutral (neither pronoun is approved) |
| "There are three bolts on the panel" | "The panel has three bolts" |
| "Make sure the valve is open" | "Make sure **that** the valve is open" |

### Phrasal verbs

Both halves being approved does not approve the pair. See rule 9.3.

| Phrasal | Single verb |
|---|---|
| carry out | do |
| set up | install, assemble |
| put out (a fire) | extinguish |
| give off | release |
| go down / go up (a value) | decrease / increase |
| find out | learn |
| take off (a part) | remove |
| turn on / turn off | *(approved — these two are the standard power-state verbs)* |

---

## List B — Plain English (every register, always)

Nothing here is about STE. These swaps improve any prose, including fiction.

### Wordy phrase → short word

| Do not use | Use |
|---|---|
| in order to | to |
| due to the fact that | because |
| in the event that | if |
| at this point in time | now |
| prior to | before |
| subsequent to | after |
| in the vicinity of | near |
| a large number of | many |
| the majority of | most |
| has the ability to | can |
| it is possible that | may, or delete |
| for the purpose of | to, for |
| with regard to | about |
| in spite of the fact that | although |

### Nominalization → verb

The single highest-yield edit in business writing. A verb hiding inside a noun makes a
sentence longer, flatter, and vaguer.

| Do not use | Use |
|---|---|
| perform an analysis of | analyze |
| make a decision | decide |
| conduct an investigation | investigate |
| provide assistance | help |
| give consideration to | consider |
| reach an agreement | agree |
| take into account | count, include |
| is indicative of | shows |
| has a requirement for | needs |

### The flagged vocabulary

Words that appear far more often in generated text than in human text. Any one of them
is fine. Four on a page is a signature. See `ai-tells.md` entry 10 for the full list and
the reasoning.

| Do not use | Use |
|---|---|
| delve into | examine, dig into |
| leverage (verb) | use |
| harness (verb) | use |
| foster | encourage, cause |
| underscore | show, emphasize |
| navigate (figurative) | handle, deal with |
| crucial, pivotal, vital | important, or delete |
| robust | reliable, or give the number |
| seamless | *(delete — it almost never means anything)* |
| comprehensive | complete, or delete |
| myriad, plethora | many |
| landscape, realm, tapestry (figurative) | name the actual thing |
| game-changer | *(say what changed)* |
| in today's fast-paced world | *(delete the whole clause)* |
