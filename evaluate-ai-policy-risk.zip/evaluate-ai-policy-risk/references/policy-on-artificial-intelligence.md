# P1: Policy On Artificial Intelligence

Source: Policy on Artificial Intelligence-3.pdf

Corporate policy P1037, final, current version 2026; published May 6, 2026

## PDF page 1

```text
                                                                                             Authored By: Erica Lowry
                                                                                     Published On: 5/6/2026 10:00 AM


Policy on Artificial Intelligence
Establishes a corporate-wide framework to ensure safe, efficient, lawful, and ethical implementation
and use of AI.

The Policy outlines requirements for the development and use of AI systems and models by Red Cross
departments and business units, as well as use of AI systems and devices by employees, volunteers and
contractors for Red Cross work.



              For a PDF of this page, select the three vertical dots ⠇at the top right and choose 'Save to PDF'.




                                                                                Policy Sections
   Status                       Final

   Policy ID                    P1037
                                                                         1. Purpose
   Responsible Office           Office of the Preside                    2. Scope
                                nt and CEO                               3. Definitions
                                                                         4. Policy Statement
   Sponsor                      President and CEO
                                                                         5. Roles and Responsibilities
   Interdependencies            Risk Management P                        6. Enforcement Responsibility
   (if any)                    olicy                                     7. Implementation and Communication
                               Protecting Personal I                     8. Source of Authority/Legislative Context
                               nformation Policy                         9. Associated Documents
                               Technology Governa
                               nce Policy




                                                                               Policy Contact: AI at Red Cross




1. Purpose
The American Red Cross (the “Red Cross”) leverages artificial intelligence (“AI”) technologies to achieve its
mission. The Policy on Artificial Intelligence (the “Policy”) establishes a corporate-wide framework to ensure
safe, efficient, lawful, and ethical implementation and use of AI.




                                        http://onesource.redcross.org/page/13965
```

## PDF page 2

```text
The Policy outlines requirements for the development and use of AI by Red Cross departments and business
units, as well as use of AI Systems and devices by employees, volunteers and contractors for Red Cross work.
The Policy also details the approval process that shall ensure AI-related risks are identified, assessed and
managed before Red Cross systems are exposed to those risks.




 ""


2. Scope
This is a corporate-wide Policy and applies to all employees, volunteers, and contractors, who develop,
procure, implement, monitor or consume AI for organizational purposes and who work with third-party
suppliers and sub-processors for these purposes. Employees, volunteers and contractors who are
responsible for third-party suppliers and sub-processors shall ensure that third-party suppliers and sub-
processors contracts and services are in alignment with this Policy. The Policy applies to all design,
development, testing, production, installation, utilization, contracting and purchasing related to use of AI in
Red Cross IT Solutions and on devices issued by the Red Cross and on personal devices used for Red Cross
work purposes.




 ""


3. Definitions
Agentic AI refers to artificial intelligence systems that are designed to autonomously make decisions and
act, with the ability to pursue complex goals, often with limited to no human intervention.
Artificial Intelligence (“AI”) means systems or algorithms designed to learn with little or no human
intervention and to generalize that learning to new data, including systems designed to simulate human
reasoning.
AI Incident refers to any failure, security breach, privacy violation, performance drift, or non-compliance
event related to an AI Model or infrastructure.
AI Models refers to the various architectures and approaches used to build artificial intelligence systems,
with each designed for different tasks and data types. Types of AI Models include, but are not limited to,
Language Models, Vision Models, Audio & Speech Models, Multimodal Models, Reinforcement Learning
Models, Graph-Based Models, Time Series Models, Symbolic AI Models, and Hybrid Models.
AI Systems refers to technologies that use algorithms and data to perform tasks requiring human-like
intelligence, such as analyzing information, making decisions, or generating content.
Drift occurs when the data an AI Model was trained on differs significantly from the data it experiences in
the real world, or when an AI System’s responses to the same input change meaningfully compared to
previous versions. Drift can result in the AI Model being outdated or inaccurate.
Generative AI (“GenAI”) refers to a type of AI technology that generates text, audio, code, images,
simulations or videos by drawing upon large, preexisting data sets.


                                   http://onesource.redcross.org/page/13965
```

## PDF page 3

```text
Hallucinations is the term that describes how GenAI models may integrate or can provide false or
inaccurate information as fact in a response to a prompt.
Intellectual Property is any product of human intellect that the law protects from unauthorized use by
others. The ownership of intellectual property establishes a period of exclusive right for the owner of the
intellectual property rights to exploit and benefit from the creation. Intellectual property is traditionally
comprised of four categories: patent, copyright, trademark, and trade secret.
IT Solution is an IT service or application that supports functions for the organization’s operations. It is a
discrete set of resources organized for the collection, processing, maintenance, use, sharing, or disposition
of information. An IT Solution could be internally developed or supported externally by a supplier, and
includes on premises software and infrastructure, software and services that operate in a Red Cross cloud
storage account, or software and services that are hosted and offered by a supplier as a service.
Model Bias, also known as algorithm bias or AI bias, occurs when AI technology produces results or outputs
that are systemically prejudiced, biased, or erroneous. Model Bias can arise from the selection of training
data, features used to build the model, algorithms used to train the model, individuals who create the AI
algorithms, how the model is implemented, or the AI algorithms themselves.
Personally Identifiable Information (“PII”) is any information that identifies or can be used to identify a
specific individual. Examples of PII include an individual’s name, address, birth date, telephone number, e-
mail address, photographs, information relating to an individual’s blood donations, employee identification
numbers, as well as more sensitive types of identifying information including, but not limited to, Social
Security numbers, driver’s license numbers, financial information, health records, and biometric data.




 ""


4. Policy Statement
The Red Cross uses AI to improve the efficiency and effectiveness of its operations in order to achieve its
mission. The Red Cross recognizes that the unrestricted use of AI has the potential to pose risk to the
organization, including but not limited to operational, reputational, legal and cybersecurity risks.
In order to manage potential risks, Red Cross employees, volunteers and contractors are required to design,
implement, procure, and use AI Systems and models in accordance with the following framework:

      • Employees, volunteers and contractors shall procure IT Solutions following the Procurement and
        Contracting Policy, which includes review by AI Governance Council (“AIGC”) for systems utilizing AI,
        regardless of the cost or the source of payment;
      • Employees, volunteers and contractors shall only use AI approved in accordance with the AI
        Governance Procedure for organizational purposes. Employees, volunteers and contractors shall not
        use unapproved AI tools on their personal devices for Red Cross work, consistent with the IT Standard
        for Acceptable Use of IT Resources;
      • Employees, volunteers and contractors shall use, design and implement AI in a manner that protects
        sensitive Red Cross information, in accordance with the Protecting Personal Information Policy and
        the IT Standard – Secure Data Handling;
      • Employees, volunteers and contractors shall use AI Models in a responsible manner, consistent with
        this Policy and as detailed in the Appendix;
      • The Red Cross shall manage risks posed by software suppliers’ use of AI; and

                                   http://onesource.redcross.org/page/13965
```

## PDF page 4

```text
    • Employees, volunteers and contractors shall comply with laws and regulations applicable to the
      design and use of AI.

Red Cross employees, volunteers and contractors shall also adhere to the corporate policies and standards
when using AI Systems and AI Models including, but not limited to those listed above and:

    • Confidential Information and Intellectual Property Agreement;
    • Information Security Policy;
    • IT Change Management Policy;
    • Protecting Personal Information Policy; and
    • Policy on Trademarks Ownership, Use and Licensing.

They should also adhere to the IT Standard for Acceptable Use of IT Resources, which details acceptable use
of Red Cross IT resources and restricts the use of personal computers and devices, and to the IT Standard for
Data Classification and IT Solution Categorization, which details the requirements for classifying and
protecting Red Cross data. Internally developed AI Models must adhere to the AI Model Standard. Changes
to AI Systems and infrastructure should follow the IT Change Management Policy.
Red Cross employees, volunteers and contractors shall only use AI in a manner compliant with Red Cross
Licensing Procedure, Brand Standards and the requirements in
Appendix A. Any use of AI to generate text, images, audio or video shall ensure the protection of the Red
Cross Intellectual Property, including the name and emblem and other registered and unregistered
trademarks owned by the American Red Cross.
In the event of a potential or suspected AI Incident, the identifying party must notify the AI Governance
team, Information Security, and the Privacy Officer, as soon as they are aware an incident may have
occurred.
Any Red Cross employee, volunteer or contractor found to be using AI or have used or installed AI and/or
created or distributed GenAI content in violation of this Policy may face disciplinary action, up to and
including termination of employment or volunteer service or the termination of a contractor’s services,
depending on the impact to the organization.


4.1 IT Approval of AI Systems, Infrastructure and Models
Red Cross departments and units shall follow the AI Governance Procedure and secure Red Cross
Information Technology (“IT”) approval when developing, using, or installing AI on Red Cross IT Solutions.
Department Heads will work with the AIGC, as detailed in the AI Governance Procedure, to ensure that the
proposed use of AI mitigates the potential for human or programmatic harm. IT shall also work with
departments and units to manage AI Models and AI Systems over time and thereby mitigate the effects of
Drift, Model Bias, or Hallucinations on Red Cross operations.
Red Cross-managed and/or created infrastructure used for AI, such as on-premises or cloud-based
computing environments, must be assessed for risk and inventoried by the AIGC, as well as approved for
use by the Architecture Review Board (“ARB”), prior to launch.
AIGC, in collaboration with Enterprise Architecture, will maintain and post a comprehensive listing of all
approved AI infrastructures and applications, either created internally or procured.
The IT approval process shall ensure that AI-related risks are identified, assessed and managed before Red
Cross is exposed to those risks. IT shall apply security practices in alignment with the Information Security
Policy and conduct ongoing monitoring of AI Systems and AI Models to avoid unintended results that could
harm the Red Cross. IT shall also work with the Office of General Counsel to adhere to the Protecting
Personal Information Policy and incorporate privacy principles in the development, adoption, and/or use of


                                  http://onesource.redcross.org/page/13965
```

## PDF page 5

```text
any AI technologies


4.2 Responsible Use of AI Systems and GenAI

4.2.1 AI Systems
The Red Cross may implement AI in association with IT Solutions in order to improve operational efficiency
and effectiveness and enhance the organization’s ability to achieve its mission. The Red Cross shall develop,
implement and/or use on Red Cross IT Solutions only AI tools that have received a Risk Assessment
conducted by AIGC and have subsequently been approved by IT, as detailed in the AI Governance
Procedure.

4.2.2 Generative AI
Red Cross employees, volunteers and contractors shall use IT-approved GenAI tools in a responsible manner
that protects the Red Cross, including but not limited to the following:

    • Employees, volunteers and contractors shall use only those GenAI tools that IT has approved and
      made available to use for Red Cross work. No Red Cross information shall be entered in publicly
      accessible GenAI tools that are not Red Cross approved;
    • Employees, volunteers and contractors are responsible for confirming the accuracy of GenAI output
      before using it in Red Cross works or to inform corporate decision-making. Individuals using GenAI
      shall verify that outputs are free of hallucinations and model bias and otherwise ensure that output is
      valid and appropriate before using it for Red Cross purposes. Employees, volunteers and contractors
      shall comply with applicable legal requirements to notify the public of its use of Gen AI;
    • Agentic AI systems present significant additional risk to the Red Cross. Agentic AI systems may be
      permitted, provided all required approvals and acceptance requirements have been met in
      accordance with the AI Governance Procedure, the system is explainable and traceable (e.g., includes
      reviewable logs documenting its reasoning process and actions), and the use case is assessed as ‘Low’
      or ‘Moderate’ risk on both the Policy and Analytic dimensions. High risk applications may request
      approval from the Chief Information Officer through the Exception and Risk Acceptance process;
    • Red Cross work developed with the use of GenAI shall include a footnote or watermark—such as
      “created by AI interface”—when the source of the content is unclear or when the product is
      substantially generated by AI. This practice supports transparency for end users and helps maintain
      trust in the integrity of Red Cross communications and deliverables;
    • Employees, volunteers and contractors shall never use GenAI in a manner that violates public trust
      including, but not limited to, creating authentic-seeming imagery of Red Cross events, locations or
      spokespeople;
    • Use of IT approved Gen-AI tools for the creation of internal-facing video training and presentations
      utilizing human-like AI Avatars is permitted and must follow the Guidance for Internal Use of Real
      Human AI Avatars;
    • Red Cross departments and business units shall take actions to mitigate the risk GenAI poses to its
      business operations including, but not limited to, deep fake communications and cybersecurity risks;
    • Red Cross Technical Owner shall collaborate with AIGC to conduct and document an Algorithmic Bias
      Assessment using AIGC‑approved methodologies as part of the AI Governance Procedure;
    • Red Cross departments and units shall conduct ongoing monitoring, periodic risk reassessments, and
      performance evaluations of IT-approved AI Systems as deemed necessary to minimize AI-related risks
      and ensure compliance with the intent of this Policy. Responsibility for compliance rests with the
      respective department head. AIGC is available for consultation and may issue guidance related to this

                                  http://onesource.redcross.org/page/13965
```

## PDF page 6

```text
        requirement.;and
      • Each department and unit shall establish decommissioning criteria and escalation procedures for
        every IT-approved AI System under its purview. Where appropriate, existing IT decommissioning
        processes may be utilized. Escalation procedures for operational issues shall follow the provisions
        outlined in Section 4 of this Policy regarding AI-related incidents.

The Policy Appendix provides an overview of acceptable and prohibited use of GenAI for Red Cross work.


4.3 Mitigate Risks Associated with Supplier Use of AI
All Red Cross contracts with suppliers shall require suppliers to disclose the use of AI in the provision of
software, deliverables, goods and services to Red Cross. Procurement and contracting, onboarding and
contract renewal of software suppliers shall include risk assessment as detailed in the AI Governance
Procedure for all use of AI. Red Cross IT shall determine whether further assessment or monitoring of each
software supplier is necessary.


4.4 Comply with Applicable Laws and Regulations.
The Red Cross and its employees, volunteers and contractors shall comply with all applicable laws and
regulations relating to AI, including but not limited to those concerning non-discrimination, fairness, and
transparency in the use of algorithmic decision-making software. The Red Cross and its employees,
volunteers and contractors shall also act in accordance with legal requirements to disclose the use of AI,
including GenAI, to any party, as required by law, such as, job applicants, employees, donors or clients.




 ""


5. Roles and Responsibilities
The Chief Information Officer (“CIO”)is responsible for providing strategic IT leadership and direction to
the organization, including:

      • Provides input and advice on use of technology resources for the Red Cross, including leadership of
        and vision for AI initiatives.
      • Communicates regularly with Senior Leadership about AI evolution, possibilities and risks.
      • Ensures the provision of online resources and troubleshooting support in order to guide the Red
        Cross workforce in appropriate use of AI.
      • Oversees the work of Enterprise AI to ensure that potential AI-related risks are assessed, identified
        and managed prior to exposing Red Cross IT systems.

The Vice President, Enterprise AI is responsible for oversight of the Artificial Intelligence Governance
Council, which provides guidance to Red Cross on AI policy, creates standards to assist in the
implementation of AI policy, provides experts to assist in determining AI risk, and catalogs all AI Systems in
use at the Red Cross. The Vice President is accountable for implementation and management of an AI
governance process that assesses risk associated with prospective AI Systems in a time-sensitive manner
and monitors approved systems and models on an ongoing basis and make improvements as needed.


                                   http://onesource.redcross.org/page/13965
```

## PDF page 7

```text
The Office of General Counsel (“OGC”) provides legal advice and counsel on laws, rules and regulations
impacting Red Cross business operations including on privacy, intellectual property and other laws
applicable to the use of AI. OGC, through the Chief Privacy Officer, is responsible for communicating
privacy principles for incorporation in the development, adoption, and use of AI Systems, assessing the use
of PII in AI Systems used at the Red Cross, and co-leading cyber incident responses with the Chief
Information Security Officer. OGC’s Office of Ethics and Compliance manages ethics and integrity
misconduct investigations, including any reports of misuse of AI.
The Chief Information Security Officer (“CISO”) is responsible for monitoring and protecting Red Cross
data. The CISO is responsible for leading efforts to protect the Red Cross against cybersecurity risks, as
detailed in the Information Security Policy. The CISO shall co-lead cyber incident responses with the Chief
Privacy Officer.
The Chief Human Resources Officer will ensure that the Red Cross workforce has access to training that
builds corporate-wide knowledge and skills to help ensure corporate-wide use of AI in accordance with the
Policy.
The Senior Vice President, Government Relations shall provide updates and information on AI-related
legislation and regulations as they are issued.
The Senior Leadership, such as department level Presidents or Chief Officers, of the Red Cross are the
primary accountable executives for ensuring there is a process and framework for managing corporate-wide
AI risk at the Red Cross.
Department Heads, defined as division level Vice Presidents, are responsible for managing AI risk in
their respective departments and units. They are responsible for ensuring that their workforce is aware of
the Policy and for enforcing the Policy in their units, including but not limited to adhering to the Procedure
on AI Governance when developing AI Systems and ensuring GenAI output is reviewed for accuracy and
watermarked in accordance with the Policy.
Solution Owner is the role with operational authority for a specified system or portfolio of systems that is
accountable for the overall implementation of business processes and controls. The Solution Owner
provides leadership and strategic direction for the IT Solution by defining high-level business requirements
and validating that the IT Solution meets the expected business outcomes and monitors and adjusts for AI
System failures and performance drift. The Solution Owner is the accountable department heads (e.g., Vice
President) closest to where the IT Solution is used in daily operations.




 ""


6. Enforcement Responsibility
Users of Red Cross IT Systems are responsible for complying with the Policy and reviewing Policy and
Procedure documents at least on an annual basis. Users are encouraged to take AI-related training to build
their understanding of and skill in using AI Systems and AI Models.
The CIO and Senior Leadership are responsible for ensuring compliance with this Policy. Department Heads
shall oversee the development of AI procedures and tools specific to their departments and units in order to
enforce the Policy in their respective areas.
The Red Cross reserves the right to access and monitor any Red Cross-issued devices and/or personal
devices used for Red Cross work purposes to ensure adherence to the Policy.



                                  http://onesource.redcross.org/page/13965
```

## PDF page 8

```text
 ""


7. Implementation and Communication
The Policy will be implemented and communicated to the organization in a coordinated manner across the
following departments:

      • IT will catalog all AI Systems in use and advise departments and units of the required AI governance
        processes.
      • IT will conduct corporate-wide training for continual understanding of Red Cross-approved AI tools
        for the use of employees, volunteers and contractors in accordance with the Policy.
      • Enterprise AI will lead the establishment and enablement efforts of AI-related training across the
        organization to build understanding and skills enterprise wide. Human Resources will partner with
       Enterprise AI and provide support in areas including workforce alignment and learning design and
       delivery. These efforts will focus on specific topics such as how AI generates specific outcomes, how
       to use AI Systems effectively and ethically, identifying opportunities where AI can address business
       challenges and improve service delivery efficiency, and understanding AI-related risks.
      • Marketing and Communications will maintain guidelines for AI use with Red Cross trademarks and
        restrictions on use of AI to generate realistic-seeming images, audio and video. Image creation for
       internal and external use shall be created with Marketing and Communications approval.

The Policy will be communicated to the organization making use of email, OneSource and corporate
communications such as Cross Connection. It will be referenced in orientations for new employees and
volunteers. The Policy may be modified as circumstances warrant and revisions will be communicated in a
timely manner.




 ""


8. Source of Authority/Legislative Context
Section 11.4 of the Amended and Restated Bylaws of the American Red Cross states: “The Board delegates
to the Chief Executive Officer, or his or her designee, the authority to promulgate subordinate written
directives, policies, and regulations of the Corporation, not inconsistent with the Congressional Charter, the
Bylaws, or any other action, resolution, or policy of the Board. These Management Policies and Regulations
shall be part of the overall Corporate Policies and Regulations.”




 ""

                                   http://onesource.redcross.org/page/13965
```

## PDF page 9

```text
9. Associated Documents
     • AI Governance Procedure
     • AI Model Standard
     • Appendix: Acceptable and Prohibited Use of GenAI
     • Protecting Personal Information Policy
     • Confidential Information and Intellectual Property Agreement
     • Information Security Policy
     • Policy on Trademarks Ownership, Use and Licensing
     • Brand Resources and Templates
     • IT Standard – Data Classification and IT Solution Categorization
     • IT Standard – Acceptable Use of IT Resources




 Policy Background                                        Original Issue:     2024

  Authorized by: President & CEO                          Current Version:    2026
  Supersedes policy: N/A                                  Scheduled Review:   2029




""




                                  http://onesource.redcross.org/page/13965
```

