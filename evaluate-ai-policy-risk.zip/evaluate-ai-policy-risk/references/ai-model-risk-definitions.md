# R1: Ai Model Risk Definitions

Source: AI Model Risk Definitions_15ab437131d14eb680a00462f1956ea5-221026-1652-10.pdf

Supporting risk definitions; no explicit revision date

## PDF page 1

```text
AI Model Risk Definitions
         Bottom Line Up Front
         Term Definitions
         Instructions for Solution Owners and Model Authors
         Risk Levels
         Policy Based Risks
         Analytical Risks


Bottom Line Up Front
         ARC is corporately governed by the Risk Management Policy with software governed through the Information Technology Policy and Enterprise
         Architecture, Services Process.
         AI models may pose additional risks addressed by the AI Policy and AI Governance Procedures.
         AI Models are assessed at levels of either Assessing, Low, Moderate and High consistent with the ARC Data Classification Policy and IT
         Governance.
         Each model is assessed for two categories of risk, described below. Risk levels are proposed by the AI Governance council and accepted by the
         Solution Owner. The Solution Owner is ultimately responsible for accepting all areas of identified risk and ensuring risk levels are updated and
         reviewed by the AIGC as the models and use cases change. The Model Owner should assist the Solution Owner in evaluating Analytical Risk
         and working with the AIGC to determine a solution's Analytical Risk profile.
         This page defines these levels and categories in more detail.




Term Definitions
A Model is a software program that applies algorithms to data to recognize patterns, make predictions or make decisions without human intervention.
While software in general can have bugs, a model can have inherent error that may change as it is applied to new observations. So, a model is distinct
from the application system that applies it.

A Solution Owner is a Vice President level leader who has operational authority for a specified system or portfolio of systems is accountable for the
overall implementation of business processes and controls. The Solution Owner provides leadership and strategic direction for the IT Solution by defining
high level business requirements and validating that the IT Solution meets the expected business outcomes. The Solution Owner is the accountable senior
business leader (e.g., Vice President) closest to where the IT Solution is used in daily operations.

A Model Author is the person responsible for ensuring the AI model’s analytical risk assessments and documentation are current throughout the model’s
lifecycle. The Model Author is generally the individual that built and tested the model (e.g., Data Scientist, Machine Learning Engineer, etc.). When the
model is a feature of external soft, the 3rd party supplier becomes model author.

Risks levels are defined in more detail below.




Instructions for Solution Owners and Model Authors
     1. Ensure that the application system that applies the model has met the following other, general controls. Issues like application availability and
        security are addressed there.
              a. The IT Governance & Controls Checklist.
              b. The Data Classification and IT Solution Categorization Standard and its Procedure.
     2. Create an entry (a confluence page) in the AI Model Inventory.
              a. If a page for your model has not been created there, use the "Add a new model" button at the top of that page.
              b. Fill in the governed properties section with the related contacts for Solution Owner and Model Author.
              c. If the Model is External, provided by third party software, the Model Author should be a contact at the software vendor.
     3. In text field for the property called Risk, provide two assessments: a Low, Moderate and High decision for each Policy Risk and Analytical
        Risk. If you can't make that a judgment yet, use the level Assessing. Like this:


                    Risk                         AI Policy Risks:       ASSESSING

                                                        LOW                MEDIUM

                                                        HIGH


                                                 Analytical Risks:      ASSESSING

                                                        LOW                MEDIUM

                                                        HIGH



     4. In the model's Description field, include an explanation for the basis of your assessments.

    5. Use the IT Customer Portal to Request Something > IT Services > Request AI Governance Council (AIGC) Review with the particulars of your
model.
```

## PDF page 2

```text
     6. The following meeting of the AIGC's approval subgroup will include an acceptance or followup on your assessment.

     7. When accepted, the AI Governance Council will forward approval to the Enterprise Architecture process.




Risk Levels
The risk level for an AI Model is determined in a given category (Policy, Analytical) by combining the probability and size of a serious negative impact on
the Red Cross mission and operations.

         ASSESSING if the model is in development but has not been given an approved risk level yet.

         LOW if the impact would have a limited adverse effect that, for example, might: (i) cause a degradation in mission capability to an extent and
         duration that the organization is able to perform its primary functions, but the effectiveness of the functions is noticeably reduced; (ii) result in
         minor damage to organizational assets; (iii) result in minor financial loss; or (iv) result in minor harm to individuals.

         MODERATE if the impact would have a serious adverse effect that, for example, might: (i) cause a significant degradation in mission capability to
         an extent and duration that the organization is able to perform its primary functions, but the effectiveness of the functions is significantly reduced;
         (ii) result in significant damage to organizational assets; (iii) result in significant financial loss; or (iv) result in significant harm to individuals that
         does not involve loss of life or serious life threatening injuries.

         HIGH if the impact would have a severe or catastrophic adverse effect that, for example, might: (i) cause a severe degradation in or loss of
         mission capability to an extent and duration that the organization is not able to perform one or more of its primary functions: (ii) result in major
         damage to organizational assets; (iii) result in major financial loss; or (iv) result in severe or catastrophic harm to individuals involving loss of life
         or serious life threatening injuries.



Policy Based Risks
AI Policy Risk refers to risk identified in the AI Policy and address mostly non-technical risks of AI.

The AI Policy requires that all AI models be subject to the AI Governance Procedure to ensure:

         IT Approval of AI Systems and Models
         Adherence to Red Cross Corporate Policies including
                 Confidential Information and Intellectual Property Agreement;
                 Information Security Policy;
                 Protecting Personal Information Policy; and
                 Policy on Trademarks Ownership, Use and Licensing.
         Responsible Use of AI Systems and GenerativeAI
         Risks Associated with Software Supplier Use of AI are mitigated
         Compliance with applicable laws and regulations.

In IT Governance terms, the Solution Owner has operational authority for a specified system or portfolio of systems who is accountable for the overall
implementation of business processes and controls. The Solution Owner provides leadership and strategic direction for the IT Solution by defining high
level business requirements and validating that the IT Solution meets the expected business outcomes. The Solution Owner is the accountable senior
business leader (e.g., Vice President) closest to where the IT Solution is used in daily operation.



Analytical Risks
Analytical Risk refers to technical, often scientific, risks involved in the development, deployment, and ongoing support of AI models, such as stability,
minimum performance standards and algorithmic fairness. This category identifies monitors & alerts needed upon deployment. This category spans these
concerns:

         Drift risk - that the model becomes increasingly erroneous in the face of new data (input and output)
         Bias risk - that the model's response distribution by protected class (race, gender, ethnicity,eg) changes in the face of new data
         Alignment risk - that a generative model responds inappropriately.
         Algorithmic risk - that a model's initial algorithm selection needs to change on next training.

In IT Governance terms, the Model Author is the person responsible for ensuring the AI model’s analytical documentation are current throughout the
model’s lifecycle. The Model Author is generally the individual that built and tested the model (e.g., Data Scientist, Machine Learning Engineer, etc.).
```

