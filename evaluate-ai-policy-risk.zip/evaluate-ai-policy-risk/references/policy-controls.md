# Policy control map

Use this as a navigation aid; verify material findings against the sources. IDs below are evaluator labels, not official policy numbering.

## Corporate requirements: internal, external and hybrid AI

| ID | Requirement and applicability | Source |
| --- | --- | --- |
| P-01 | Follow procurement/AI governance regardless of cost/payment source; use approved AI for organizational work, including personal devices. | P1 §4, pp. 3-4 |
| P-02 | AIGC assessment and IT approval; inventory/assess Red Cross-managed or created AI infrastructure and obtain ARB approval before launch. | P1 §§4.1-4.2.1, pp. 4-5 |
| P-03 | Protect sensitive information/PII; follow referenced security, secure-handling, classification and privacy requirements. Do not invent unavailable standards' detailed rules. | P1 §§4-4.1, pp. 3-5 |
| P-04 | Protect Red Cross IP/name/emblem/trademarks; follow licensing/brand requirements. | P1 §4, p. 4 |
| P-05 | Verify GenAI accuracy, bias, hallucinations and appropriateness before organizational use/decisions; no ARC information in unapproved publicly accessible GenAI. | P1 §4.2.2, p. 5 |
| P-06 | Agentic use requires approvals/acceptance, explainability/traceability and Low/Moderate on both dimensions; High requires CIO Exception and Risk Acceptance route. | P1 §4.2.2, p. 5 |
| P-07 | Footnote/watermark when provenance is unclear or work substantially AI-generated; applicable public disclosure. | P1 §4.2.2, p. 5; §4.4, p. 6 |
| P-08 | Do not undermine public trust, including authentic-seeming fabricated Red Cross imagery. Internal human-like avatars require approved tools/referenced guidance; image creation requires Marketing and Communications approval. | P1 §4.2.2, p. 5; §7, p. 8 |
| P-09 | Technical Owner collaborates with AIGC on documented Algorithmic Bias Assessment using approved methodologies. | P1 §4.2.2, p. 5 |
| P-10 | Ongoing monitoring, periodic risk/performance reassessment as needed, decommissioning criteria and escalation; accountable department head. | P1 §4.2.2, pp. 5-6 |
| P-11 | Notify AI Governance, Information Security and Privacy Officer as soon as a potential/suspected AI incident is known. | P1 §4, p. 4 |
| P-12 | Supplier contracts disclose AI; risk assessment at procurement/contracting, onboarding and renewal; subprocessors within scope. | P1 §2, p. 2; §4.3, p. 6 |
| P-13 | Follow IT change management for AI systems/infrastructure and applicable laws. Do not assert current law from historical guidance. | P1 §4, p. 4; §4.4, p. 6 |

R1 pp. 1-2 directs model inventory entries with Solution Owner and Model Author/vendor contact, both ratings and their basis; request AIGC review through IT Customer Portal; accepted assessment proceeds to Enterprise Architecture. Verify current routing before any operational submission. Never submit or contact others solely because this skill describes the process.

## Internal models: I1 applicability

I1 expressly applies to internally developed AI models. For hybrid solutions scope to internal models and identify analogous engineering evidence for integration/agent components without pretending it is expressly mandated by I1. Do not demand vendor source-code disclosure based solely on the internal version-control requirement.

| Control | Required evidence | Source |
| --- | --- | --- |
| 0.1 | General IT/compliance, architecture, applicable GenAI use restrictions, security/classification/change-management alignment. | I1 p. 1 |
| 0.2 | Model inventory/metadata; AIGC risk assessment. | I1 p. 1 |
| 1.1 | Code location, training/inference data connections, application dependencies, analytical rationale/risk basis. | I1 p. 1 |
| 1.2 | Versioned code and prediction dependencies, including data flows, inference datasets and baseline/evaluation results; multi-person support/reproducibility. | I1 p. 2 |
| 1.3 | Held-out validation, documented accuracy expectations, baseline bias/fairness/ethical evaluation reflecting affected populations. | I1 p. 2 |
| 1.4 | Peer review of model/code/documentation for feedback/revision. | I1 p. 2 |
| 2.1 | Periodic reevaluation for error/drift against baseline, usage monitoring, cost per use if available. | I1 p. 2 |
| 2.2 | Independent security/access management and ITSM configuration item for models serving multiple applications; single-app models may rely on application security. | I1 p. 2 |

## External and analytical guidance

E1 p. 1 asks about prior assessments, incremental value/risk, training on ARC data, audiences, failure modes, initial/ongoing validation ownership, drift/bias/stability, GenAI restrictions, affected people, PII/IP leakage, reuse benefiting other customers, responsible AI and retraining/change management.

- Preserve E1's direction that third-party models **should not** train on ARC internal sources; do not silently turn guidance into a new legal prohibition. Identify training/reuse and necessary governance/contract review.
- If ARC inputs/usage benefit other customers, E1 calls for OGC involvement/additional agreement terms; these alone do not establish approval.
- Apply deterministic-feature distinctions at component level; model-driven tool choice remains AI.
- Do not repeat E1's historical generalization about court rulings as current law. Use current primary legal sources only if needed and refer legal interpretation to OGC.

Q1 p. 1 reinforces prior-use comparison, validation responsibility, PII/IP/responsible-use risks, drift/retraining, sensitivity to training data/architecture, and consequences of error. R1 p. 2 defines drift, bias, alignment and algorithmic risk. Consider environmental impacts where relevant as a Q1 question, not an invented scoring category.

## Additional user requirement

**U-OTEL (user instruction, October 22, 2026):** For agentic purposes, tracing/observability must be captured by organizational systems and all logs stored through the organization's OTEL approach. Apply to relevant agentic reviews unless the user updates scope. Label provenance; no supplied PDF explicitly prescribes OTEL.

Assess customer-controlled ingestion/storage, event completeness, model/tool/action correlation, sampling, retries/replay, outage/loss behavior, retention, redaction/access. Do not invent retention duration, require secrets or hidden model chain-of-thought, or treat OTEL as the storage backend itself. Clarify event scope and sensitive-payload handling. Distinguish native OTLP from conversion of other formats. A gateway cannot prove coverage of unobserved internal steps. Decision summaries and recorded actions are evidence against P-06, not automatic proof of compliance without governance acceptance.

**Firewall:** The user asked where inference runs, without establishing a blanket external-inference ban. Treat boundary location as an architecture/data-handling question unless a supplied rule requires one. Distinguish local workflows, private transit, model hosting, provider processing and telemetry. External inference or PII use is not automatic High.

## Missing dependencies

Not bundled: complete AI Governance Procedure; GenAI acceptable/prohibited-use appendix; bias methodology; detailed security, privacy, classification, secure-handling, change-management and procurement standards; brand/licensing/avatar rules; full exception process. Record relevant gaps and request documents when needed. Do not reconstruct missing provisions, assume an OTEL clause/data-residency requirement, or claim complete compliance without applicable evidence.
