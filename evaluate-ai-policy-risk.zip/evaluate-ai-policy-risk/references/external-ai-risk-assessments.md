# E1: External Ai Risk Assessments

Source: External AI Risk Assessments_096d9ffb9d4c4e929d8906632cc0d357-221026-1651-6.pdf

External assessment guidance; no explicit revision date

## PDF page 1

```text
External AI Risk Assessments
The Supplier Management includes IT governance on third party software or service suppliers.

This process also identifies AI features and triggers the AI Governance approval process.




  General Questions

 Do we already have this       If so, its prior risk assessment informs that of the new feature. Also, if so, what is the change in value the new feature
 feature?                      provides? A 'solution owner' may accept incremental risk for incremental reward.

 Is the feature trained        An AI feature is built by learning from a dataset (training), then applying that learning to other data (inference). A third
 upon ARC data?                party model should not be trained upon ARC internal data sources.

 Who uses the feature's AI     An AI feature that is used by the public has a greater risk than one limited to ARC staff.
 result?

  Analytical Risk

 When is the feature           We define AI features as those that have inherent error. If a feature is deterministic - specific rule driven outputs - then it's
 wrong?                        errors are just bugs and it doesn't need AI governance. If a feature involves predictions, probabilities or generative output,
                               it can be off so we'll need to know more about its engineering.

 How is the feature            We want to be clear on roles and responsibilities. Is the ARC responsible for initial testing (baseline error) and monitoring
 validated?                    errors over time. We want to know how it will assess drift, bias and analytical stability.

  Policy Risk

 Does the feature use          For GenAI use, there are additional requirements and prohibitions found here.
 Generative AI with text,
 images, video or audio?

 Who is affected by the        Does the feature affect ARC blood donors, financial donors, disaster victims, general public experience? The wider the
 features results?             audience the more risk sensitivity.

 How does the feature use      A feature that is trained upon or applied to ARC data has a risk of passing that data through in its output. This is a shared
 ARC content?                  concern with InfoSec and Data Classification policies.

      Any confidential
      information of
      donors, employees
      or others?
      Any Red Cross
      intellectual property
      like trademarks?


 Does any ARC                  If the vendor takes ARC inputs or usage to improve/apply the feature outside the ARC, the Office of General Counsel will
 information benefit           have additional terms in the agreement.
 vendors other clients?

 How does the feature          This is very open ended. Might the feature's performance expose ARC intellectual property, involve biases, lack
 address general concerns      explainability or introduce any of these challenges. In recent US rulings, a company's algorithms represent public speech
 of "responsible AI"?          so the company is liable for any of the algorithm's statements.

 How/Will the feature be re-   We want to prepare for the change management of occasional re-training.
 trained over time?
```

