# Q1: Ai Model Risk Questions

Source: Questions to help determine AI m_2393e4013a1f4881ab52fa4055fda606-221026-1652-12.pdf

Supporting risk questions; no explicit revision date

## PDF page 1

```text
Questions to help determine AI model risk
General
      Does the ARC already do something like this? We can benefit from risk assessments considered on other services.
      Has the model been validated?
      Who is responsible for its ongoing validation?


Policy Risk
      Does the AI enabled service use Generative AI with text, image, video or audio processing? If so, we have a couple prohibitions to review.
      Does the service use people's confidential information? There may be risk that confidential information is accidentally shared by the output of the
      service.
      Does the service use Red Cross intellectual property like trademarked materials? Similarly, we're concerned the service might inadvertently pass
      it through into the model's outputs.
      How does the AI service ensure that its used responsibly, safely, legally and ethically? Discuss risks of privacy, racism, sexism, ageism or
      environmental impacts.


Analytical Risk
      How is the model's performance monitored for drift? How often will the model need to be re-trained?
      How sensitive is the model to it's training dataset? This is called data drift.
      How sensitive is the model's architecture to new training data? This is called algorithmic drift.
      What happens when the model is wrong?
```

