# I1: Ai Model Standards

Source: AI Model Standards_50f0e5b773af415c9c311e36badb95e4-221026-1652-8.pdf

Internal model standard, Version 1, September 30, 2024

## PDF page 1

```text
AI Model Standards
Context
       These statements apply to internally developed AI models.

       The American Red Cross maintains an AI Policy directing the management of AI models.

       The subsequent AI Governance Procedures call for AI Model Standards presented here, or in the attached Word document.




Version 1 9/30/2024

 #     Condition                       Notes

 0     Prerequisites

0.1   The model meets general IT      IT Governance & Compliance instructions are here.
      standards and compliance.
                                      Enterprise Architecture guidance is here.

                                      If the solution uses Generative AI, it observes the Acceptable and Prohibited Use directions.

                                      Software applications that use the model should observe existing standards including

                                           Information Technology Policy
                                           Information Security Policy
                                           Data Classification Procedure
                                           IT Change Management Policy


0.2   AI Governance procedures        The model and its required metadata are tracked in the AI Model Inventory.
      have been completed.
                                      The model has had its risk assessed by the AIGC Review Board.

       Model Development

1.1   Basic documentation is          Documentation must include:
      available.
                                           the location of source code supporting the model
                                           specific connections to data sources serving both model training and subsequent inference
                                           any application systems that depend upon the model, or that the model depends upon
                                           statements on analytical reasoning and the basis of AI risks

                                      This may take the form of Word files, Powerpoint files or Confluence pages linked to the model's entry in the
                                      Model Inventory.

                                      Here are examples of model documentation:

                                           Lapsed Reactivation Model
                                           Platelet Conversion Model
                                           CFR Non-Financial Response Model
```

## PDF page 2

```text
1.2   The model's code is under          A deployed model properly belongs to the Red Cross and should be supportable by other than the Model
      version control.                   Author.

                                         The model's code should be maintained under version control to ensure multiple person support and reproduce
                                         ability.

                                         Version control may take the form:

                                              Dataiku git backend
                                              git based repositories such as gitlab
                                              Sharepoint folders with versioning setting on,
                                              confluence pages, or
                                              any design of shared folders, where deployed software is subsequently read-only.

                                         Version control should apply to anything the prediction decision relies upon including:

                                              data flows from sources to model training
                                              inference datasets
                                              baseline performance and model evaluation results (see 1.3)


1.3   The model's results have been      The model has been applied to data outside it's training inputs, and there are documented expectations for its
      validated.                         accuracy.

                                         These baseline metrics are prerequisite to drift monitoring. The model's results upon deployment include
                                         evaluation for bias, algorithmic fairness, and ethical/responsible AI concerns. These results should reflect the
                                         concerns of the people affected by the model's output, and may build upon practices specific to that business
                                         area.

1.4   Model's has been peer               The Model Author should share the model, its code and documentation, for feedback and potential revision by
      reviewed.                          others w

       Model Operations

2.1   The models is monitored for        The model is reevaluated occasionally for error, and against baseline to detect changes in a model's
      usage and drift.                   performance with the equivalent scope of 1.3.

                                         If available, this should include the cost of each use.

2.2   If the model is used by multiple   A model that is used by one application may rely on that application to maintain security. The model then is just
      applications, it has its own       a feature of the app.
      security access management
      in place.                          A model that is used by more than one application is treated as its own ITSM configuration item and needs its
                                         own security management. It should be treated as an independent application service and follow IT
                                         Governance & Compliance as well as Enterprise Architecture guidance.
```

