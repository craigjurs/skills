# Policy and Analytical risk rubric

## Authority and terminology

Use R1, AI Model Risk Definitions, pp. 1-2. Its prose defines Assessing, Low, Moderate, High. An example graphic uses MEDIUM; normalize output to Moderate, the defined level. Use Analytical Risk as the canonical label; P1 also uses Analytic in its agentic provision.

The governing method combines the probability and size of a serious negative impact on Red Cross mission and operations. No numeric scoring matrix, weights, probability bands, thresholds, or aggregation formula was supplied. Do not invent one or import another framework as corporate policy. If separately requested, label quantitative scoring an evaluator aid and preserve the corporate categories.

| Level | Source-defined meaning |
| --- | --- |
| Assessing | The model has not yet received an approved risk level; assessment instructions also direct use of Assessing when a judgment cannot yet be made. |
| Low | Limited adverse effect: noticeable degradation while primary functions continue; minor asset damage, financial loss, or individual harm. |
| Moderate | Serious adverse effect: significant degradation while primary functions continue; significant asset damage or financial loss; significant individual harm without loss of life or serious life-threatening injury. |
| High | Severe or catastrophic effect: severe degradation/loss of mission capability, including inability to perform primary functions; major asset damage or financial loss; loss of life or serious life-threatening injury. |

## Separate ratings from approval

Always distinguish:

1. **Evaluator's proposed current risk:** Each dimension independently, based on scoped use and evidenced operating controls. Use Assessing when material information prevents defensible judgment; specify what would resolve it.
2. **Official approval/inventory status:** Reproduce approved ratings only with evidence. Otherwise say Unverified/not supplied; for a new pending assessment keep official inventory status Assessing. Do not overwrite documented approval because the evaluator proposes a change; report the difference and request reassessment.

AIGC proposes levels; the Solution Owner accepts them (R1 p. 1). P1 §§4.1-4.2.1 requires AIGC assessment and subsequent IT approval, plus ARB approval for Red Cross-managed/created AI infrastructure before launch. An assistant supplies analysis for this process, not approval.

## Rating procedure

1. Define credible adverse scenarios, affected populations/exposure, consequences and likelihood. Distinguish error likelihood from likelihood of resulting harm after controls.
2. Identify operating controls and evidence of effectiveness/limitations. Do not credit planned controls as implemented.
3. Explain how probability and impact map to the definitions. Use reasoned qualitative likelihood, not unsupported percentages.
4. Assign each dimension one proposed category or Assessing. Missing documentation is not automatic High; vendor certification is not proof of Low.
5. Report evidence confidence separately (High/Medium/Low, with rationale). Medium confidence is not a risk category.
6. If useful, show unmitigated scenarios and conditional future residual targets separately. These are evaluator reporting aids, not additional mandatory corporate fields.

Known risks still require findings when other evidence is missing. Do not hide a substantiated High scenario behind Assessing; conversely, a severe hypothetical without exposure/likelihood analysis is insufficient to declare High.

## Compliance and gates

Compliance status and risk level differ. A Low-risk use case may lack mandatory approval; a High-risk system may have documented controls. Missing approval is not automatic High.

Use advisory dispositions: Ready for governance review, Further evidence required, Remediation required before proposed use, or CIO exception route required for High-risk agentic use. A pilot still requires applicable approvals; never prescribe an unauthorized pilot to avoid the gate.

Agentic deployment requires both dimensions Low/Moderate, approvals/acceptance, and explainability/traceability. Either High triggers the CIO Exception and Risk Acceptance route; either Assessing leaves the gate unresolved. Do not assume an exception waives other corporate or legal obligations.

For multiple features, report separate pairs. Describe material risks and unresolved scope in an umbrella summary without arithmetic averaging or claiming that a maximum-of-features rule is corporate policy.
