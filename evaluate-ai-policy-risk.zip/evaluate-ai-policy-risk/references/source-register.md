# Source register

Baseline supplied by the user on October 22, 2026. Preserve original PDF bytes. Extracted text is a navigation aid; the PDF controls if layout or extraction is ambiguous. Export filename dates are not policy revision dates. This bundle is not a guarantee that corporate policy has not changed.

## Source files

### P1: Policy on Artificial Intelligence-3.pdf
- Authority/version: Corporate policy P1037, final, current version 2026; published May 6, 2026.
- Original: [PDF](../assets/policy-on-artificial-intelligence.pdf).
- Readable source: [policy-on-artificial-intelligence.md](policy-on-artificial-intelligence.md).
- Pages: 9. SHA-256: `eaf73e61de3b3b4a6096bdd3058860364f69c24ecbad70c0cf07959c432bb000`.

### R1: AI Model Risk Definitions_15ab437131d14eb680a00462f1956ea5-221026-1652-10.pdf
- Authority/version: Supporting risk definitions; no explicit revision date.
- Original: [PDF](../assets/ai-model-risk-definitions.pdf).
- Readable source: [ai-model-risk-definitions.md](ai-model-risk-definitions.md).
- Pages: 2. SHA-256: `a181e1b590071cfd7ddca44fbb3a20ce43012fb23ddca0e77ecfd86dc64db0cf`.

### I1: AI Model Standards_50f0e5b773af415c9c311e36badb95e4-221026-1652-8.pdf
- Authority/version: Internal model standard, Version 1, September 30, 2024.
- Original: [PDF](../assets/ai-model-standards.pdf).
- Readable source: [ai-model-standards.md](ai-model-standards.md).
- Pages: 2. SHA-256: `79e820724d301b07104b10abcf4f82d57148564395533011965e3fbf413a7746`.

### E1: External AI Risk Assessments_096d9ffb9d4c4e929d8906632cc0d357-221026-1651-6.pdf
- Authority/version: External assessment guidance; no explicit revision date.
- Original: [PDF](../assets/external-ai-risk-assessments.pdf).
- Readable source: [external-ai-risk-assessments.md](external-ai-risk-assessments.md).
- Pages: 1. SHA-256: `fee416ad127076cde8c94e20b266ac55ef4d715826ff1d586cbd789aec5412cc`.

### Q1: Questions to help determine AI m_2393e4013a1f4881ab52fa4055fda606-221026-1652-12.pdf
- Authority/version: Supporting risk questions; no explicit revision date.
- Original: [PDF](../assets/ai-model-risk-questions.pdf).
- Readable source: [ai-model-risk-questions.md](ai-model-risk-questions.md).
- Pages: 1. SHA-256: `73a491f680791757468a8c76aee1d54c2de3d4a443ab0a898a5af630157b27a6`.

## Interpretation and missing sources

Use P1 as the current supplied corporate policy and R1 for the two risk dimensions and levels. Use I1 only within its internal-model scope. Use E1 and Q1 as supporting due-diligence guidance. Distinguish mandatory policy language from guidance such as should. If sources conflict, explain the conflict and authority/date/scope rather than silently merging them.

The referenced full AI Governance Procedure, GenAI acceptable/prohibited-use appendix, AIGC bias methodology, privacy/security/classification/secure-handling standards, brand/licensing/avatar guidance and detailed exception process were not supplied. Do not invent their provisions.

U-OTEL is an additional user requirement from October 22, 2026: for agentic purposes, tracing/observability must be captured by organizational systems and all logs stored through its OTEL approach. It is not a quoted requirement from these PDFs. The firewall question was an evaluation question, not a blanket cloud prohibition.
