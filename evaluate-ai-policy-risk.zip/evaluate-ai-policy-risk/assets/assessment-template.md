# AI solution assessment: [solution / feature / use case]

Date: [date]. Scope/version/environment: [details]. Development: [internal/external/hybrid]. Intended users/affected people: [details]. Baseline: [policy versions and limitations].

## Risk findings

| Dimension | Proposed current risk | Likelihood and impact rationale | Evidence confidence |
| --- | --- | --- | --- |
| Policy Risk | [Assessing / Low / Moderate / High] | [scenario, controls, consequence, sources] | [confidence and reason] |
| Analytical Risk | [Assessing / Low / Moderate / High] | [scenario, controls, consequence, sources] | [confidence and reason] |

Official approval/inventory status: [documented ratings/approvals with dates/scope, or Unverified; new pending assessments remain Assessing]. Proposed findings support AIGC/Solution Owner review and do not constitute approval.

Review disposition: [governance review / evidence required / remediation required / CIO exception route]. Agentic gate: [applicable? both dimensions Low/Moderate? approvals/acceptance? traceability? exception evidence?].

## Scope, architecture and accountability

[Purpose/value, model/system distinction, data/classification, output consumers, inference/telemetry boundaries, actions/permissions, assumptions and exclusions.]

| Responsibility | Named owner or unresolved | Evidence |
| --- | --- | --- |
| Solution Owner | [...] | [...] |
| Model Author / supplier contact | [...] | [...] |
| Technical / operational owner and accountable department | [...] | [...] |

[For materially different features/configurations provide separate rating pairs; never average.]

## Policy Risk analysis

[Applicable corporate controls, external guidance, internal standards, user requirements; harms/likelihood, operating controls and gaps. Cite provisions and evidence.]

## Analytical Risk analysis

[Fit-for-use validation/error consequences; drift, bias, alignment, algorithmic stability; agent failures where relevant; baseline/thresholds, monitoring and ownership. Cite evidence.]

## Controls and evidence

| Finding | Requirement and provenance | Applicability | Evidence and strength | Status | Consequence / dimension |
| --- | --- | --- | --- | --- | --- |
| [...] | [P1 section / I1 clause / E1 guidance / U-OTEL / evaluator method] | [...] | [source/date/version; asserted vs verified] | [Met / Partially met / Not met / Not evidenced / Not applicable] | [...] |

## Evidence gaps and actions

| Priority | Missing evidence or confirmed gap | Requested artifact / mitigation | Owner | Acceptance criterion / affected decision |
| --- | --- | --- | --- | --- |
| [...] | [...] | [...] | [...] | [...] |

Conditional future target, if useful: [rating contingent on verified controls, separate from current risk].

## Monitoring and reassessment

[Metrics/baselines/thresholds, owners/cadence, alerts/incidents, rollback/decommissioning; flag unknowns. Reassess for changes to use cases, data/populations, models/providers, prompts/tools/permissions, deployment, incidents or performance.]

## Inventory-ready description

AI Policy Risks: [proposed category]. Analytical Risks: [proposed category]. [Short basis for each, scope, approval status, unresolved conditions and owner; label proposed if unapproved.]

## Sources and limitations

[Policy titles/versions/sections/pages; solution URLs/documents/access dates; fact-sheet coverage if relevant; missing dependencies, inaccessible evidence and contradictions.]

*AI-generated draft assessment for human governance review; not an approval or risk acceptance.*
