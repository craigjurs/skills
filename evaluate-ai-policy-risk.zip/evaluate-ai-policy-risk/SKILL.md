---
name: evaluate-ai-policy-risk
description: Evaluate internal, external, and hybrid AI solutions against American Red Cross AI policy and governance documents. Use for AI vendor due diligence, internally developed models, generative or agentic AI, architecture and observability reviews, model-inventory assessments, and reassessments. Produce separate Policy Risk and Analytical Risk findings using Assessing, Low, Moderate, or High, with evidence, compliance gaps, mitigations, ownership, and approval requirements.
---

# Evaluate AI Policy and Analytical Risk

Evaluate a defined use case and configuration, not a vendor brand. Produce an evidence-backed assessment for human governance review; never issue or imply institutional approval.

## Load the governing material

1. Read [source register](references/source-register.md), [policy controls](references/policy-controls.md), and [risk rubric](references/risk-rubric.md) for every assessment.
2. Read relevant page-numbered extracts before making material policy findings. Source extracts: [P1 corporate policy](references/policy-on-artificial-intelligence.md), [R1 risk definitions](references/ai-model-risk-definitions.md), [I1 internal standards](references/ai-model-standards.md), [E1 external assessments](references/external-ai-risk-assessments.md), [Q1 risk questions](references/ai-model-risk-questions.md). The register identifies the original PDFs; consult them if extraction is ambiguous.
3. Read [evidence guide](references/evidence-guide.md) when gathering evidence and [assessment template](assets/assessment-template.md) before writing the result.
4. Use the supplied baseline without claiming it is the latest corporate policy. Record versions and assessment date. If a newer authoritative source is supplied, identify changes and apply it to the assessment; do not silently rewrite this skill.
5. Separate corporate requirements, supporting guidance, user-supplied requirements, and evaluator recommendations. Resolve scope/date differences explicitly; never invent unavailable referenced documents.

## Establish the assessment boundary

Extract solution, feature/model/version, purpose, deployment, internal/external/hybrid development ownership, affected people, data classification, output users, autonomy, permissions, consequential actions, and existing approvals. Identify the Solution Owner, Model Author/vendor contact, Technical Owner, operational owner, and accountable department; leave unknown identities unresolved.

Use available evidence first. Ask only questions that would materially change the assessment. If scope remains incomplete, produce a bounded preliminary assessment with assumptions and evidence requests instead of manufacturing a use case or withholding useful work.

Assess materially different features, configurations, models, and use cases separately. For hybrid systems, assign responsibilities to internal components and suppliers. Do not automatically apply internal-model standards to an external foundation model or assume an internal wrapper is itself a trained model; document actual applicability.

Identify deterministic components, but assess model-driven selection/actions in the surrounding system. A deterministic tool does not exempt an agent from governance. If the entire scoped solution is verified non-AI, record AI governance applicability as Not applicable with a rationale and leave AI risk fields unassigned; do not invent a fifth risk level.

## Gather and evaluate evidence

Use authorized attachments, internal artifacts, official technical documentation, contracts, evaluations, configurations, and operational records. Browse current official sources for changeable vendor capabilities unless prohibited by the user. Never expose confidential source contents in public queries or upload corporate material to vendors. Do not send questionnaires, change settings, or run live tests without applicable authorization.

For fact-sheet indexes, enumerate relevant sheets and FAQs; when asked for a complete review, read all sections and keep a coverage list. Mark inaccessible, unreviewed, irrelevant, and contradictory evidence. Do not transfer claims from one feature to another. Distinguish marketing/vendor assertions from contract-backed or demonstrated controls.

For each material finding, record requirement source/section, applicability, evidence source/date/version, asserted or observed behavior, uncertainty, consequence, and responsible party. Use statuses Met, Partially met, Not met, Not evidenced, Not applicable. Do not label operational controls verified solely on vendor assertions. Silence is Not evidenced, not proof of absence; explicit failure is Not met, not merely unknown.

## Assess Policy Risk

Apply references/policy-controls.md: approvals/inventory, supplier disclosure/contracts, data/PII/IP protection, responsible use, output verification/disclosure, agent traceability, bias-assessment governance, change management, incidents, monitoring, and decommissioning. Cite actual provisions; distinguish unavailable evidence from confirmed breaches.

For external solutions, assess application vendors, model providers and subprocessors. Distinguish inference, training, fine-tuning, improvement, abuse monitoring, telemetry and storage. Examine contracts and configuration, not provider branding alone.

For internal models, also apply I1 controls 0.1 through 2.2: documentation, code/data/evaluation versioning, held-out validation, peer review, monitoring and shared-service security.

For agentic use, apply the corporate gate: required approvals/acceptance, explainability/traceability, and Low or Moderate on both dimensions; High requires the CIO Exception and Risk Acceptance route. Assessing does not satisfy the gate. Never assume an exception exists.

## Assess Analytical Risk

Assess baseline validity/performance, consequences of error, input/output drift, protected-class bias/fairness, alignment/inappropriate responses, algorithmic stability and retraining/model changes. Examine representative held-out evaluation, subgroup results, failure cases, monitoring thresholds, alert ownership, fallback/rollback, review and reproducibility. Cover predictive, generative, vision, audio, and other models according to their use.

For agents, also examine tool selection, arguments/results, multi-step error propagation, permissions, termination/retries, prompt injection/tool misuse, and review of consequential actions. Label these engineering checks as evaluator methods supporting policy, not verbatim corporate mandates.

Explain realistic adverse scenarios, likelihood, and impact on mission, assets, finances, and individuals. Do not assign Low because hosting is internal or High solely because a solution is external, agentic, handles PII, or lacks documentation. Do not average away serious risks using unrelated control successes.

## Assign and report the two ratings

Use only Assessing, Low, Moderate, or High for each AI dimension. Follow references/risk-rubric.md to distinguish proposed current ratings from official approval/inventory status. Rate independently; one may be Assessing while the other is substantiated. State evidence confidence separately.

Base current risk on evidenced operating controls. Keep future mitigation targets conditional and separate. Identify confirmed violations, evidence gaps and approval blockers even when risk remains Assessing. Do not hide a known severe risk behind missing information elsewhere.

Render assets/assessment-template.md in chat by default; create a file when requested or otherwise appropriate under artifact rules. Lead with both ratings, rationale, scope and review disposition. Include an inventory-ready description, per-feature ratings where needed, control/evidence matrix, prioritized actions with owners, and monitoring/reassessment triggers. Never blend dimensions into an overall score.

## Final quality check

- Include both ratings, permitted terminology, likelihood/impact rationale, and proposed-versus-approved status.
- Distinguish source versions, facts, assumptions, interpretations, and contradictions.
- Recognize good evidence alongside gaps; cite every material compliance and solution claim.
- Check internal-standard applicability and supplier/internal responsibilities.
- Apply agentic gates and label OTEL's user-supplied provenance.
- Make recommendations proportionate and concrete; never invent approval, acceptance or implemented controls.
